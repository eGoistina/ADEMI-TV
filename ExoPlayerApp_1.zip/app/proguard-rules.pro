# ProGuard rules for ExoPlayerApp
