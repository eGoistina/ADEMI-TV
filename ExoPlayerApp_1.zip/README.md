# ExoPlayer App – GitHub Actions CI/CD

## Schnellstart

1. **ZIP entpacken**
2. **Auf GitHub hochladen:**
   - Neues Repository erstellen
   - `Add files via upload` → alle entpackten Dateien hochladen
   - **Wichtig:** Ordnerstruktur beibehalten (`.github/workflows/` muss erhalten bleiben!)
3. **Workflow startet automatisch** bei Push auf `main`
4. **APK herunterladen:**
   - Gehe zu **Actions** → wähle den letzten Run
   - Scrolle zu **Artifacts** → lade `ExoPlayer-Debug-APK` herunter
   - Oder: Gehe zu **Releases** → dort wird die APK automatisch veröffentlicht

## Was passiert im Hintergrund?

Der GitHub Actions Workflow (`.github/workflows/android.yml`) macht folgendes:
1. Installiert JDK 17
2. Installiert Android SDK
3. Generiert den Gradle Wrapper (`gradle wrapper`)
4. Baut die Debug-APK (`./gradlew assembleDebug`)
5. Lädt die APK als Artifact hoch
6. Erstellt automatisch ein GitHub Release mit der APK

## Lokale Entwicklung

Wenn du lokal in Android Studio arbeiten willst:

```bash
# Gradle Wrapper generieren (einmalig nötig, da die wrapper.jar nicht im ZIP ist)
gradle wrapper --gradle-version 8.7

# Oder direkt bauen
gradle assembleDebug
```

## Projektstruktur

```
ExoPlayerApp/
├── .github/workflows/android.yml   # CI/CD Pipeline
├── app/                             # Android App Modul
│   ├── build.gradle.kts
│   └── src/main/...
├── gradle/wrapper/                  # Wrapper Konfiguration
├── gradlew / gradlew.bat           # Wrapper Skripte
├── build.gradle.kts                # Root Build
└── settings.gradle.kts
```

## Features

- Media3 ExoPlayer (aktuellster Standard)
- 3 Demo-Videos (Big Buck Bunny, Elephants Dream, Tears of Steel)
- Fullscreen-Video-Player mit Custom Controls
- Play/Pause, Vor/Zurück Navigation
- Automatische GitHub Actions Build & Release

## Troubleshooting

**Workflow schlägt fehl?**
- Prüfe, ob die Ordnerstruktur korrekt ist (`.github/workflows/android.yml` muss exakt so heißen)
- Stelle sicher, dass alle Dateien hochgeladen wurden
- Unter **Actions** → klicke auf den fehlgeschlagenen Run → **Re-run jobs**
