# АДЕМИ ТВ 2.0

Dies ist die vollständig neu aufgebaute Version der App.

## Neue Identität
- Paketkennung: `world.torbesi.ademitv`
- Version: `2.0.0`
- Das neue Torbeši-Logo ist App-Symbol und Hauptlogo.
- Die App wird von Android als neue, eigenständige App erkannt.

## Funktionen
- Xtream-Codes-Anmeldung
- Oberfläche vollständig in mazedonischer Kyrilliza
- Große, seniorengerechte Schaltflächen
- Македонски, Српски, Босански, Исламски, Спортски
- Nur deutsche Filme, keine Serien
- Sprachsuche mit toleranter Namenssuche
- Favoriten durch langes Drücken
- Integrierter Videoplayer

## GitHub
Die ZIP-Datei unverändert als `MK-Xtreme-Player-Source.zip` hochladen und die vorhandene Datei ersetzen.
Danach baut der vorhandene GitHub-Workflow die APK.
