# АДЕМИ ТВ 2.2 – direkte M3U-Plus/MPEG-TS-Version

- Keine Loginmaske.
- Der vollständige `get.php`-Link ist in `AppData.java` integriert.
- Die App lädt die M3U-Plus-Liste, liest `group-title` und die echten Stream-URLs.
- Live-Kanäle werden direkt als MPEG-TS abgespielt.
- Keine HLS-/M3U8-Umwandlung.
- Kategorien: Македонски, Српски, Босански, Исламски, Спортски, германски филмови.

Hinweis: Zugangsdaten in einer APK können technisch ausgelesen werden.
