# АДЕМИ ТВ 2.1 – TS Direct

Diese Android-App verwendet die Xtream-Codes-API nur zum Laden von Kategorien und Senderlisten. Live-TV wird anschließend direkt als MPEG-TS geöffnet:

`SERVER/live/BENUTZER/LOZINKA/STREAM_ID.ts`

Es gibt keine Auswahl und keine Wiedergabe für M3U8/HLS. Das Formatfeld wurde entfernt.

## GitHub-Build

Die ZIP-Datei unverändert unter dem Namen `MK-Xtreme-Player-Source.zip` hochladen. Der Workflow entpackt das Projekt und erzeugt das Artefakt `ADEMI-TV-2.1-TS-APK`.

Hinweis: Eine Serverdomain, die im DNS nicht auflösbar ist, kann auch von der App nicht erreicht werden. In diesem Fall muss die korrekte aktuelle Serveradresse des Anbieters verwendet werden.
