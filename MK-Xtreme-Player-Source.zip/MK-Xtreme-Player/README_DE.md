# АдемиТВ Xtreme Codes 3.0

Dieses Android-Projekt wurde vollständig neu aufgebaut. Es ist nicht nur eine Änderung der alten App.

## Technische Grundlage

- Neue Paketkennung: `world.torbesi.ademitvxtreme`
- Version: `3.0.0`
- Xtreme-Codes-API über `player_api.php`
- Integrierter M3U-Plus-Ersatzweg über `get.php?...&type=m3u_plus&output=mpegts`
- Live-TV direkt als MPEG-TS (`/live/Benutzer/Passwort/Stream-ID.ts`)
- Filme über den Xtreme-VOD-Endpunkt
- Serien und Episoden über `get_series` und `get_series_info`
- Favoriten, Kanalsuche, Sprachsuche, EPG, Serverprüfung und veränderbare Zugangsdaten
- HTTP-Cleartext ist ausdrücklich für ältere IPTV-Portale freigegeben
- DNS-over-HTTPS-Ersatzweg ist eingebaut, falls nur die lokale DNS-Auflösung blockiert ist

## Bereits eingetragene Daten

Die vom Auftraggeber gelieferten Server-, Benutzer- und Passwortdaten sind als Standardwerte im Projekt hinterlegt. Sie können in der App unter **Поставки** geändert werden.

## APK mit GitHub Actions bauen

Bei einem direkt entpackten Repository:

1. Repository bei GitHub öffnen.
2. **Actions** öffnen.
3. Workflow **ADEMI TV Xtreme Codes 3.0 bauen** starten oder eine Änderung auf `main` hochladen.
4. Nach dem grünen Haken unten das Artefakt **ADEMI-TV-XTREME-CODES-APK** herunterladen.
5. ZIP entpacken und `ADEMI-TV-XTREME-CODES-3.0.apk` installieren.

## Wichtiger technischer Hinweis

Eine App kann nur dann Inhalte laden, wenn der IPTV-Server tatsächlich erreichbar ist und die Zugangsdaten aktiv sind. Der Quellcode enthält sowohl den normalen Xtreme-Codes-Weg als auch den vollständigen M3U-Plus-Ersatzweg.
