# АДЕМИ ТВ 2.3 – direkte Serverkommunikation mit DNS-Fallback

- Der vollständige `get.php`-Link ist fest in `AppData.java` integriert.
- Beim Start lädt die App die Playlist sofort und zeigt sichtbar `ПОВРЗАНО` oder `НЕ Е ПОВРЗАНО`.
- Die M3U-Plus-Datei wird robust gelesen, auch mit UTF-8-BOM und nicht-standardisierten Attributen.
- Live-Kanäle werden direkt als MPEG-TS abgespielt; keine HLS-/m3u8-Umwandlung.
- HTTP/cleartext ist über eine eigene Android-Netzwerkkonfiguration ausdrücklich erlaubt.
- Wenn Androids DNS den Servernamen nicht findet, versucht die App eine DNS-over-HTTPS-Abfrage und verbindet sich anschließend über die ermittelte IPv4-Adresse mit korrektem Host-Header.
- Version 2.3.0 / versionCode 23.

Hinweis: Zugangsdaten in einer APK können technisch ausgelesen werden.
