# ADEMI TV 2.0 – no custom shrinking rules required.
