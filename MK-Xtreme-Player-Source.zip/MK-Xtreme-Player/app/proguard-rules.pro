# No shrinking in this project. This file is kept for release-build compatibility.
