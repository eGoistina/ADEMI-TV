package com.adnan.mkxtremeplayer;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class HomeActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (!AppConfig.hasLogin(this)) {
            startActivity(new Intent(this, MainActivity.class));
            finish();
            return;
        }
        setContentView(R.layout.activity_home);

        TextView accountText = findViewById(R.id.accountText);
        accountText.setText("Корисник: " + AppConfig.username(this));

        bindSection(R.id.macedonianButton, AppConfig.SECTION_MACEDONIAN, "Македонски", "mk-MK");
        bindSection(R.id.serbianButton, AppConfig.SECTION_SERBIAN, "Српски", "sr-RS");
        bindSection(R.id.bosnianButton, AppConfig.SECTION_BOSNIAN, "Босански", "bs-BA");
        bindSection(R.id.islamicButton, AppConfig.SECTION_ISLAMIC, "Исламски", "mk-MK");
        bindSection(R.id.sportsButton, AppConfig.SECTION_SPORTS, "Спортски", "mk-MK");
        bindSection(R.id.moviesButton, AppConfig.SECTION_GERMAN_MOVIES, "Филмови", "de-DE");

        Button favoritesButton = findViewById(R.id.favoritesButton);
        favoritesButton.setOnClickListener(v -> {
            Intent intent = new Intent(this, ChannelActivity.class);
            intent.putExtra("favorites", true);
            intent.putExtra("title", "Омилени");
            intent.putExtra("voice_language", "mk-MK");
            startActivity(intent);
        });

        Button logoutButton = findViewById(R.id.logoutButton);
        logoutButton.setOnClickListener(v -> {
            AppConfig.clearLogin(this);
            startActivity(new Intent(this, MainActivity.class));
            finish();
        });
    }

    private void bindSection(int buttonId, String section, String title, String voiceLanguage) {
        Button button = findViewById(buttonId);
        button.setOnClickListener(v -> {
            Intent intent = new Intent(this, ChannelActivity.class);
            intent.putExtra("section", section);
            intent.putExtra("title", title);
            intent.putExtra("voice_language", voiceLanguage);
            startActivity(intent);
        });
    }
}
