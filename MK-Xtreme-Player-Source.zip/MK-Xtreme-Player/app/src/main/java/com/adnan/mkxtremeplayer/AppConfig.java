package com.adnan.mkxtremeplayer;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Scanner;

final class AppConfig {
    static final String SECTION_MACEDONIAN = "macedonian";
    static final String SECTION_SERBIAN = "serbian";
    static final String SECTION_BOSNIAN = "bosnian";
    static final String SECTION_ISLAMIC = "islamic";
    static final String SECTION_SPORTS = "sports";
    static final String SECTION_GERMAN_MOVIES = "german_movies";

    static final String MEDIA_LIVE = "live";
    static final String MEDIA_MOVIE = "movie";

    private static final String PREFS = "mk_xtreme_prefs";
    private static final String SERVER = "server";
    private static final String USERNAME = "username";
    private static final String PASSWORD = "password";
    private static final String OUTPUT = "output";
    private static final String FAVORITES = "favorites";

    private AppConfig() {}

    static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static void saveLogin(Context context, String server, String username, String password, String output) {
        prefs(context).edit()
                .putString(SERVER, normalizeServer(server))
                .putString(USERNAME, username.trim())
                .putString(PASSWORD, password)
                .putString(OUTPUT, output)
                .apply();
    }

    static void clearLogin(Context context) {
        prefs(context).edit().remove(SERVER).remove(USERNAME).remove(PASSWORD).apply();
    }

    static boolean hasLogin(Context context) {
        return !server(context).isEmpty() && !username(context).isEmpty() && !password(context).isEmpty();
    }

    static String server(Context context) {
        return prefs(context).getString(SERVER, "");
    }

    static String username(Context context) {
        return prefs(context).getString(USERNAME, "");
    }

    static String password(Context context) {
        return prefs(context).getString(PASSWORD, "");
    }

    static String output(Context context) {
        return prefs(context).getString(OUTPUT, "m3u8");
    }

    static String normalizeServer(String server) {
        String result = server == null ? "" : server.trim();
        if (!result.startsWith("http://") && !result.startsWith("https://")) {
            result = "http://" + result;
        }
        while (result.endsWith("/")) {
            result = result.substring(0, result.length() - 1);
        }
        return result;
    }

    static String apiUrl(Context context, String action, String categoryId) {
        Uri.Builder builder = Uri.parse(server(context) + "/player_api.php").buildUpon()
                .appendQueryParameter("username", username(context))
                .appendQueryParameter("password", password(context));
        if (action != null && !action.isEmpty()) {
            builder.appendQueryParameter("action", action);
        }
        if (categoryId != null && !categoryId.isEmpty()) {
            builder.appendQueryParameter("category_id", categoryId);
        }
        return builder.build().toString();
    }

    static String streamUrl(Context context, Channel item) {
        String extension;
        if (MEDIA_MOVIE.equals(item.mediaType)) {
            extension = cleanExtension(item.extension, "mp4");
            return Uri.parse(server(context)).buildUpon()
                    .appendPath("movie")
                    .appendPath(username(context))
                    .appendPath(password(context))
                    .appendPath(item.streamId + "." + extension)
                    .build().toString();
        }

        extension = cleanExtension(output(context), "m3u8");
        return Uri.parse(server(context)).buildUpon()
                .appendPath("live")
                .appendPath(username(context))
                .appendPath(password(context))
                .appendPath(item.streamId + "." + extension)
                .build().toString();
    }

    private static String cleanExtension(String value, String fallback) {
        String extension = value == null ? "" : value.trim().toLowerCase(Locale.ROOT);
        while (extension.startsWith(".")) extension = extension.substring(1);
        return extension.isEmpty() ? fallback : extension;
    }

    static String httpGet(String urlString) throws Exception {
        HttpURLConnection connection = (HttpURLConnection) new URL(urlString).openConnection();
        connection.setRequestMethod("GET");
        connection.setConnectTimeout(12000);
        connection.setReadTimeout(25000);
        connection.setRequestProperty("User-Agent", "ADEMI-TV/1.1");
        int code = connection.getResponseCode();
        if (code < 200 || code >= 300) {
            throw new IllegalStateException("HTTP " + code);
        }
        try (Scanner scanner = new Scanner(connection.getInputStream(), StandardCharsets.UTF_8)) {
            scanner.useDelimiter("\\A");
            return scanner.hasNext() ? scanner.next() : "";
        } finally {
            connection.disconnect();
        }
    }

    static boolean isCategoryForSection(String section, String categoryName) {
        String value = normalizeForMatching(categoryName);
        switch (section == null ? "" : section) {
            case SECTION_MACEDONIAN:
                return containsAny(value,
                        "macedon", "makedon", "макед", "north macedonia",
                        "severna makedonija", "северна македонија")
                        || hasToken(value, "mk") || hasToken(value, "мк");
            case SECTION_SERBIAN:
                return containsAny(value, "serb", "srb", "срб", "serbia", "srbija", "србија");
            case SECTION_BOSNIAN:
                return containsAny(value, "bosn", "босн", "bosna", "bosnia")
                        || hasToken(value, "bih") || hasToken(value, "бих");
            case SECTION_ISLAMIC:
                return containsAny(value,
                        "islam", "islams", "ислам", "muslim", "муслим",
                        "quran", "kuran", "куран", "diyanet", "dini", "religija islam");
            case SECTION_SPORTS:
                return containsAny(value, "sport", "спорт");
            case SECTION_GERMAN_MOVIES:
                return containsAny(value,
                        "deutsch", "german", "germany", "герман", "немач")
                        || hasToken(value, "de") || hasToken(value, "deu") || hasToken(value, "ger");
            default:
                return false;
        }
    }

    private static String normalizeForMatching(String value) {
        if (value == null) return " ";
        return " " + value.toLowerCase(Locale.ROOT)
                .replaceAll("[^\\p{L}\\p{N}]+", " ")
                .replaceAll("\\s+", " ")
                .trim() + " ";
    }

    private static boolean containsAny(String value, String... parts) {
        for (String part : parts) {
            if (value.contains(part)) return true;
        }
        return false;
    }

    private static boolean hasToken(String value, String token) {
        return value.contains(" " + token + " ");
    }



    static boolean matchesSearch(String candidate, String query) {
        String q = normalizeSearchText(query);
        if (q.isEmpty()) return true;
        String c = normalizeSearchText(candidate);
        if (c.contains(q)) return true;

        String[] tokens = q.split(" ");
        int matched = 0;
        int useful = 0;
        for (String token : tokens) {
            if (token.length() < 2) continue;
            useful++;
            if (c.contains(token)) matched++;
        }
        return useful > 0 && matched == useful;
    }

    static Channel findBestMatch(List<Channel> items, String query) {
        String q = normalizeSearchText(query);
        if (q.isEmpty()) return null;
        Channel best = null;
        int bestScore = 0;
        for (Channel item : items) {
            int score = matchScore(item.name, q);
            if (score > bestScore) {
                bestScore = score;
                best = item;
            }
        }
        return bestScore >= 55 ? best : null;
    }

    private static int matchScore(String candidate, String normalizedQuery) {
        String c = normalizeSearchText(candidate);
        if (c.isEmpty() || normalizedQuery.isEmpty()) return 0;
        if (c.equals(normalizedQuery)) return 100;
        if (c.startsWith(normalizedQuery)) return 92;
        if (c.contains(normalizedQuery)) return 80;

        int score = 0;
        String[] tokens = normalizedQuery.split(" ");
        for (String token : tokens) {
            if (token.length() < 2) continue;
            if (c.contains(token)) score += 20;
        }
        if (c.replace(" ", "").contains(normalizedQuery.replace(" ", ""))) score += 15;
        return score;
    }

    static String normalizeSearchText(String value) {
        if (value == null) return "";
        StringBuilder out = new StringBuilder();
        String lower = value.toLowerCase(Locale.ROOT)
                .replace('č', 'c')
                .replace('ć', 'c')
                .replace('š', 's')
                .replace('ž', 'z');

        for (int i = 0; i < lower.length(); i++) {
            char ch = lower.charAt(i);
            switch (ch) {
                case 'а': out.append('a'); break;
                case 'б': out.append('b'); break;
                case 'в': out.append('v'); break;
                case 'г': out.append('g'); break;
                case 'д': out.append('d'); break;
                case 'ѓ': out.append("gj"); break;
                case 'е': out.append('e'); break;
                case 'ж': out.append('z'); break;
                case 'з': out.append('z'); break;
                case 'ѕ': out.append("dz"); break;
                case 'и': out.append('i'); break;
                case 'ј': out.append('j'); break;
                case 'к': out.append('k'); break;
                case 'л': out.append('l'); break;
                case 'љ': out.append("lj"); break;
                case 'м': out.append('m'); break;
                case 'н': out.append('n'); break;
                case 'њ': out.append("nj"); break;
                case 'о': out.append('o'); break;
                case 'п': out.append('p'); break;
                case 'р': out.append('r'); break;
                case 'с': out.append('s'); break;
                case 'т': out.append('t'); break;
                case 'ќ': out.append("kj"); break;
                case 'у': out.append('u'); break;
                case 'ф': out.append('f'); break;
                case 'х': out.append('h'); break;
                case 'ц': out.append('c'); break;
                case 'ч': out.append('c'); break;
                case 'џ': out.append("dz"); break;
                case 'ш': out.append('s'); break;
                case 'đ': out.append("dj"); break;
                default:
                    if (Character.isLetterOrDigit(ch)) out.append(ch);
                    else out.append(' ');
                    break;
            }
        }

        return out.toString()
                .replaceAll("\\b(hd|fhd|uhd|4k|sd|tv|hevc|backup)\\b", " ")
                .replaceAll("[^a-z0-9]+", " ")
                .replaceAll("\\s+", " ")
                .trim();
    }

    static List<Channel> getFavorites(Context context) {
        List<Channel> result = new ArrayList<>();
        String raw = prefs(context).getString(FAVORITES, "[]");
        try {
            JSONArray array = new JSONArray(raw);
            for (int i = 0; i < array.length(); i++) {
                result.add(Channel.fromJson(array.getJSONObject(i)));
            }
        } catch (Exception ignored) {
        }
        return result;
    }

    static boolean isFavorite(Context context, String streamId, String mediaType) {
        for (Channel item : getFavorites(context)) {
            if (item.streamId.equals(streamId) && item.mediaType.equals(mediaType)) return true;
        }
        return false;
    }

    static boolean toggleFavorite(Context context, Channel item) {
        List<Channel> current = getFavorites(context);
        Map<String, Channel> byId = new LinkedHashMap<>();
        for (Channel saved : current) byId.put(saved.favoriteKey(), saved);
        boolean added;
        if (byId.containsKey(item.favoriteKey())) {
            byId.remove(item.favoriteKey());
            added = false;
        } else {
            byId.put(item.favoriteKey(), item);
            added = true;
        }
        JSONArray array = new JSONArray();
        for (Channel saved : byId.values()) array.put(saved.toJson());
        prefs(context).edit().putString(FAVORITES, array.toString()).apply();
        return added;
    }

    static final class Channel {
        final String streamId;
        final String name;
        final String categoryId;
        final String mediaType;
        final String extension;

        Channel(String streamId, String name, String categoryId, String mediaType, String extension) {
            this.streamId = streamId;
            this.name = name;
            this.categoryId = categoryId;
            this.mediaType = mediaType == null || mediaType.isEmpty() ? MEDIA_LIVE : mediaType;
            this.extension = extension == null ? "" : extension;
        }

        String favoriteKey() {
            return mediaType + ":" + streamId;
        }

        JSONObject toJson() {
            JSONObject object = new JSONObject();
            try {
                object.put("stream_id", streamId);
                object.put("name", name);
                object.put("category_id", categoryId);
                object.put("media_type", mediaType);
                object.put("extension", extension);
            } catch (Exception ignored) {
            }
            return object;
        }

        static Channel fromJson(JSONObject object) {
            return new Channel(
                    object.optString("stream_id"),
                    object.optString("name", "Канал"),
                    object.optString("category_id"),
                    object.optString("media_type", MEDIA_LIVE),
                    object.optString("extension")
            );
        }
    }
}
