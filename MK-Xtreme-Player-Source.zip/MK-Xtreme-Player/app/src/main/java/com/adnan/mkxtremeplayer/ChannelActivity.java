package com.adnan.mkxtremeplayer;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ChannelActivity extends AppCompatActivity {
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final List<AppConfig.Channel> allItems = new ArrayList<>();
    private final List<AppConfig.Channel> shownItems = new ArrayList<>();
    private final List<String> shownNames = new ArrayList<>();

    private ArrayAdapter<String> adapter;
    private ProgressBar progress;
    private TextView status;
    private EditText searchInput;
    private boolean favoritesMode;
    private boolean movieMode;
    private String section;
    private String voiceLanguage;
    private String titleValue;
    private ActivityResultLauncher<Intent> speechLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

        speechLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() != Activity.RESULT_OK || result.getData() == null) return;
                    ArrayList<String> matches = result.getData().getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                    if (matches != null && !matches.isEmpty()) {
                        searchInput.setText(matches.get(0));
                        searchInput.setSelection(searchInput.length());
                    }
                }
        );

        favoritesMode = getIntent().getBooleanExtra("favorites", false);
        section = getIntent().getStringExtra("section");
        movieMode = AppConfig.SECTION_GERMAN_MOVIES.equals(section);
        voiceLanguage = getIntent().getStringExtra("voice_language");
        if (voiceLanguage == null || voiceLanguage.isEmpty()) voiceLanguage = "mk-MK";
        titleValue = getIntent().getStringExtra("title");
        if (titleValue == null || titleValue.isEmpty()) titleValue = movieMode ? "Филмови" : "Канали";

        TextView title = findViewById(R.id.titleText);
        title.setText(titleValue);

        Button back = findViewById(R.id.backButton);
        back.setOnClickListener(v -> finish());

        searchInput = findViewById(R.id.searchInput);
        Button voiceButton = findViewById(R.id.voiceButton);
        ListView listView = findViewById(R.id.listView);
        progress = findViewById(R.id.listProgress);
        status = findViewById(R.id.listStatus);

        adapter = new ArrayAdapter<>(this, R.layout.list_item, R.id.itemText, shownNames);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener((parent, view, position, id) -> play(shownItems.get(position)));
        listView.setOnItemLongClickListener((parent, view, position, id) -> {
            AppConfig.Channel item = shownItems.get(position);
            boolean added = AppConfig.toggleFavorite(this, item);
            Toast.makeText(this,
                    added ? "Додадено во омилени" : "Отстрането од омилени",
                    Toast.LENGTH_SHORT).show();
            if (favoritesMode) loadFavorites();
            else applyFilter(searchInput.getText().toString());
            return true;
        });

        searchInput.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                applyFilter(s.toString());
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        voiceButton.setOnClickListener(v -> startVoiceSearch());

        if (favoritesMode) loadFavorites();
        else loadSection();
    }

    private void startVoiceSearch() {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, voiceLanguage);
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, movieMode
                ? "Кажете го името на филмот"
                : "Кажете го името на каналот");
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);
        try {
            speechLauncher.launch(intent);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "Гласовното пребарување не е достапно на овој уред.", Toast.LENGTH_LONG).show();
        }
    }

    private void loadFavorites() {
        allItems.clear();
        allItems.addAll(AppConfig.getFavorites(this));
        progress.setVisibility(View.GONE);
        status.setText(allItems.isEmpty()
                ? "Нема омилени. Долго притиснете на канал или филм."
                : formatCount(allItems.size(), "омилена ставка", "омилени ставки"));
        applyFilter("");
    }

    private void loadSection() {
        progress.setVisibility(View.VISIBLE);
        status.setText(movieMode ? "Филмовите се вчитуваат…" : "Каналите се вчитуваат…");

        executor.execute(() -> {
            try {
                String categoriesAction = movieMode ? "get_vod_categories" : "get_live_categories";
                String streamsAction = movieMode ? "get_vod_streams" : "get_live_streams";
                JSONArray categories = new JSONArray(AppConfig.httpGet(
                        AppConfig.apiUrl(this, categoriesAction, null)
                ));

                List<String> matchingCategoryIds = new ArrayList<>();
                for (int i = 0; i < categories.length(); i++) {
                    JSONObject category = categories.getJSONObject(i);
                    String id = category.optString("category_id");
                    String name = category.optString("category_name");
                    if (!id.isEmpty() && AppConfig.isCategoryForSection(section, name)) {
                        matchingCategoryIds.add(id);
                    }
                }

                Map<String, AppConfig.Channel> loaded = new LinkedHashMap<>();
                for (String categoryId : matchingCategoryIds) {
                    JSONArray streams = new JSONArray(AppConfig.httpGet(
                            AppConfig.apiUrl(this, streamsAction, categoryId)
                    ));
                    for (int i = 0; i < streams.length(); i++) {
                        JSONObject object = streams.getJSONObject(i);
                        String streamId = object.optString("stream_id");
                        if (streamId.isEmpty()) continue;
                        String mediaType = movieMode ? AppConfig.MEDIA_MOVIE : AppConfig.MEDIA_LIVE;
                        AppConfig.Channel item = new AppConfig.Channel(
                                streamId,
                                object.optString("name", movieMode ? "Филм" : "Канал"),
                                object.optString("category_id", categoryId),
                                mediaType,
                                movieMode ? object.optString("container_extension", "mp4") : ""
                        );
                        loaded.put(item.favoriteKey(), item);
                    }
                }

                runOnUiThread(() -> {
                    allItems.clear();
                    allItems.addAll(loaded.values());
                    progress.setVisibility(View.GONE);
                    if (matchingCategoryIds.isEmpty()) {
                        status.setText(movieMode
                                ? "Не е пронајдена категорија со германски филмови."
                                : "Не се пронајдени соодветни канали.");
                    } else if (allItems.isEmpty()) {
                        status.setText(movieMode ? "Нема пронајдени филмови." : "Нема пронајдени канали.");
                    } else {
                        status.setText(movieMode
                                ? formatCount(allItems.size(), "германски филм", "германски филмови")
                                : formatCount(allItems.size(), "канал", "канали"));
                    }
                    applyFilter("");
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    progress.setVisibility(View.GONE);
                    status.setText("Грешка: " + safeMessage(e));
                });
            }
        });
    }

    private String formatCount(int count, String singular, String plural) {
        return count + " " + (count == 1 ? singular : plural);
    }

    private String safeMessage(Exception e) {
        String message = e.getMessage();
        return message == null || message.trim().isEmpty() ? "непозната грешка" : message;
    }

    private void applyFilter(String query) {
        String q = query == null ? "" : query.trim().toLowerCase(Locale.ROOT);
        shownItems.clear();
        shownNames.clear();
        for (AppConfig.Channel item : allItems) {
            if (q.isEmpty() || item.name.toLowerCase(Locale.ROOT).contains(q)) {
                shownItems.add(item);
                boolean favorite = AppConfig.isFavorite(this, item.streamId, item.mediaType);
                shownNames.add((favorite ? "★  " : "") + item.name);
            }
        }
        adapter.notifyDataSetChanged();
    }

    private void play(AppConfig.Channel item) {
        Intent intent = new Intent(this, PlayerActivity.class);
        intent.putExtra("stream_url", AppConfig.streamUrl(this, item));
        intent.putExtra("stream_name", item.name);
        intent.putExtra("is_movie", AppConfig.MEDIA_MOVIE.equals(item.mediaType));
        startActivity(intent);
    }

    @Override
    protected void onDestroy() {
        executor.shutdownNow();
        super.onDestroy();
    }
}
