package com.adnan.mkxtremeplayer;

import android.os.Bundle;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.OptIn;
import androidx.appcompat.app.AppCompatActivity;
import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;

public class PlayerActivity extends AppCompatActivity {
    private ExoPlayer player;
    private PlayerView playerView;
    private LinearLayout errorPanel;
    private String streamUrl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(R.layout.activity_player);
        hideSystemBars();

        streamUrl = getIntent().getStringExtra("stream_url");
        String streamName = getIntent().getStringExtra("stream_name");
        TextView title = findViewById(R.id.playerTitle);
        title.setText(streamName == null ? "АДЕМИ ТВ" : streamName);

        playerView = findViewById(R.id.playerView);
        errorPanel = findViewById(R.id.errorPanel);
        Button retryButton = findViewById(R.id.retryButton);
        retryButton.setOnClickListener(v -> restartPlayer());
    }

    private void hideSystemBars() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            getWindow().getInsetsController().hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
        } else {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            );
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        startPlayer();
    }

    @OptIn(markerClass = UnstableApi.class)
    private void startPlayer() {
        if (player != null || streamUrl == null || streamUrl.isEmpty()) return;
        errorPanel.setVisibility(View.GONE);
        player = new ExoPlayer.Builder(this).build();
        playerView.setPlayer(player);
        player.addListener(new Player.Listener() {
            @Override
            public void onPlayerError(PlaybackException error) {
                errorPanel.setVisibility(View.VISIBLE);
            }
        });
        player.setMediaItem(MediaItem.fromUri(streamUrl));
        player.prepare();
        player.play();
    }

    private void restartPlayer() {
        releasePlayer();
        startPlayer();
    }

    private void releasePlayer() {
        if (player != null) {
            player.release();
            player = null;
        }
    }

    @Override
    protected void onStop() {
        releasePlayer();
        super.onStop();
    }
}
