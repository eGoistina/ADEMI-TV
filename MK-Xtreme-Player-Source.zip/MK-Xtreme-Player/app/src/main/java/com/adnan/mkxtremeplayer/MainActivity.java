package com.adnan.mkxtremeplayer;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONObject;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private EditText serverInput;
    private EditText usernameInput;
    private EditText passwordInput;
    private Spinner outputSpinner;
    private Button loginButton;
    private ProgressBar progressBar;
    private TextView statusText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (AppConfig.hasLogin(this)) {
            openHome();
            return;
        }
        setContentView(R.layout.activity_login);

        serverInput = findViewById(R.id.serverInput);
        usernameInput = findViewById(R.id.usernameInput);
        passwordInput = findViewById(R.id.passwordInput);
        outputSpinner = findViewById(R.id.outputSpinner);
        loginButton = findViewById(R.id.loginButton);
        progressBar = findViewById(R.id.loginProgress);
        statusText = findViewById(R.id.statusText);

        ArrayAdapter<String> outputAdapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                new String[]{"m3u8", "ts"}
        );
        outputSpinner.setAdapter(outputAdapter);
        loginButton.setOnClickListener(v -> attemptLogin());
    }

    private void attemptLogin() {
        String server = serverInput.getText().toString().trim();
        String username = usernameInput.getText().toString().trim();
        String password = passwordInput.getText().toString();
        String output = outputSpinner.getSelectedItem().toString();

        if (server.isEmpty() || username.isEmpty() || password.isEmpty()) {
            statusText.setText("Внесете сервер, корисничко име и лозинка.");
            return;
        }

        setLoading(true);
        AppConfig.saveLogin(this, server, username, password, output);
        String url = AppConfig.apiUrl(this, null, null);

        executor.execute(() -> {
            try {
                String raw = AppConfig.httpGet(url);
                JSONObject root = new JSONObject(raw);
                JSONObject userInfo = root.optJSONObject("user_info");
                boolean authenticated = userInfo != null
                        && (userInfo.optInt("auth", 0) == 1
                        || "1".equals(userInfo.optString("auth"))
                        || userInfo.optBoolean("auth", false));
                runOnUiThread(() -> {
                    if (authenticated) {
                        openHome();
                    } else {
                        AppConfig.clearLogin(this);
                        setLoading(false);
                        statusText.setText("Најавата не успеа. Проверете ги податоците.");
                    }
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    AppConfig.clearLogin(this);
                    setLoading(false);
                    statusText.setText("Нема врска со серверот: " + safeMessage(e));
                });
            }
        });
    }

    private String safeMessage(Exception e) {
        String message = e.getMessage();
        return message == null || message.trim().isEmpty() ? "непозната грешка" : message;
    }

    private void setLoading(boolean loading) {
        progressBar.setVisibility(loading ? View.VISIBLE : View.GONE);
        loginButton.setEnabled(!loading);
        statusText.setText(loading ? "Се проверува врската…" : "");
    }

    private void openHome() {
        startActivity(new Intent(this, HomeActivity.class));
        finish();
    }

    @Override
    protected void onDestroy() {
        executor.shutdownNow();
        super.onDestroy();
    }
}
