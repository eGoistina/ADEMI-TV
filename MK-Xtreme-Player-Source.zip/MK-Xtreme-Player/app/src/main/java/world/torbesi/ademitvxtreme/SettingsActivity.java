package world.torbesi.ademitvxtreme;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public final class SettingsActivity extends AppCompatActivity {
    private EditText serverInput;
    private EditText usernameInput;
    private EditText passwordInput;
    private TextView statusView;
    private XtreamConfig config;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        config = new XtreamConfig(this);
        serverInput = findViewById(R.id.et_server);
        usernameInput = findViewById(R.id.et_username);
        passwordInput = findViewById(R.id.et_password);
        statusView = findViewById(R.id.tv_settings_status);

        findViewById(R.id.btn_settings_back).setOnClickListener(v -> finish());
        findViewById(R.id.btn_test_connection).setOnClickListener(v -> testCurrentValues());
        findViewById(R.id.btn_save_settings).setOnClickListener(v -> saveValues());
        findViewById(R.id.btn_restore_default).setOnClickListener(v -> {
            config.restoreDefaults();
            loadValues();
            statusView.setText("Вградените податоци се вратени.");
        });
        loadValues();
    }

    private void loadValues() {
        serverInput.setText(config.getServer());
        usernameInput.setText(config.getUsername());
        passwordInput.setText(config.getPassword());
    }

    private boolean storeForm() {
        String server = serverInput.getText().toString().trim();
        String username = usernameInput.getText().toString().trim();
        String password = passwordInput.getText().toString().trim();
        if (server.isEmpty() || username.isEmpty() || password.isEmpty()) {
            statusView.setText("Пополнете ги серверот, корисничкото име и лозинката.");
            statusView.setTextColor(0xFFFF8E8E);
            return false;
        }
        config.save(server, username, password);
        return true;
    }

    private void saveValues() {
        if (!storeForm()) return;
        Toast.makeText(this, "Поставките се зачувани", Toast.LENGTH_SHORT).show();
        statusView.setText("Зачувано. Live TV се пушта директно како MPEG-TS.");
        statusView.setTextColor(0xFFB9FF9D);
    }

    private void testCurrentValues() {
        if (!storeForm()) return;
        statusView.setText("Се проверува врската…");
        statusView.setTextColor(0xFFB9FF9D);
        NetworkClient.IO.execute(() -> {
            try {
                Models.AuthResult auth = new XtreamApi(config).authenticate();
                runOnUiThread(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    if (auth.authorized) {
                        statusView.setText("ПОВРЗАНО · статус: " + auth.status + " · важи до: " + auth.expires);
                        statusView.setTextColor(0xFFB9FF9D);
                    } else {
                        statusView.setText("Серверот одговори, но пристапот не е активен.");
                        statusView.setTextColor(0xFFFF8E8E);
                    }
                });
            } catch (Exception error) {
                runOnUiThread(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    statusView.setText("НЕУСПЕШНО: " + NetworkClient.friendlyMessage(error));
                    statusView.setTextColor(0xFFFF8E8E);
                });
            }
        });
    }
}
