package world.torbesi.ademitvxtreme;

import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.ProgressiveMediaSource;
import androidx.media3.ui.PlayerView;

public final class PlayerActivity extends AppCompatActivity {
    public static final String EXTRA_URL = "play_url";
    public static final String EXTRA_NAME = "play_name";
    public static final String EXTRA_MEDIA_TYPE = "play_type";

    private PlayerView playerView;
    private ProgressBar progress;
    private TextView errorView;
    private TextView badgeView;
    private ExoPlayer player;
    private String mediaUrl;
    private Models.MediaType mediaType = Models.MediaType.LIVE;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(R.layout.activity_player);
        hideSystemUi();

        playerView = findViewById(R.id.player_view);
        progress = findViewById(R.id.player_progress);
        errorView = findViewById(R.id.tv_player_error);
        badgeView = findViewById(R.id.tv_player_badge);
        TextView title = findViewById(R.id.tv_player_title);

        mediaUrl = safe(getIntent().getStringExtra(EXTRA_URL));
        title.setText(safe(getIntent().getStringExtra(EXTRA_NAME)).isEmpty() ? "АдемиТВ" : getIntent().getStringExtra(EXTRA_NAME));
        try {
            mediaType = Models.MediaType.valueOf(safe(getIntent().getStringExtra(EXTRA_MEDIA_TYPE)));
        } catch (Exception ignored) {
            mediaType = Models.MediaType.LIVE;
        }
        badgeView.setText(mediaType == Models.MediaType.LIVE ? "TS-DIRECT" : mediaType.name());

        findViewById(R.id.btn_player_back).setOnClickListener(v -> finish());
        playerView.setKeepScreenOn(true);
        playerView.setControllerAutoShow(true);

        if (mediaUrl.isEmpty()) {
            showError("Нема адреса за пуштање.");
            return;
        }
        preparePlayback();
    }

    private void preparePlayback() {
        progress.setVisibility(View.VISIBLE);
        errorView.setVisibility(View.GONE);
        NetworkClient.IO.execute(() -> {
            try {
                NetworkClient.PreparedUrl prepared = NetworkClient.prepareForPlayback(mediaUrl);
                runOnUiThread(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    startPlayer(prepared);
                });
            } catch (Exception error) {
                runOnUiThread(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    showError("Не може да се отвори серверот.\n" + NetworkClient.friendlyMessage(error));
                });
            }
        });
    }

    private void startPlayer(NetworkClient.PreparedUrl prepared) {
        releasePlayer();
        DefaultHttpDataSource.Factory dataSourceFactory = new DefaultHttpDataSource.Factory()
                .setUserAgent("VLC/3.0.21 LibVLC/3.0.21")
                .setAllowCrossProtocolRedirects(true)
                .setConnectTimeoutMs(15000)
                .setReadTimeoutMs(45000)
                .setDefaultRequestProperties(prepared.headers);

        MediaItem.Builder itemBuilder = new MediaItem.Builder().setUri(prepared.url);
        String lowerUrl = prepared.url.toLowerCase(java.util.Locale.ROOT);
        if (mediaType == Models.MediaType.LIVE && !lowerUrl.contains(".m3u8")) {
            itemBuilder.setMimeType(MimeTypes.VIDEO_MP2T);
        }
        MediaItem mediaItem = itemBuilder.build();

        ProgressiveMediaSource mediaSource = new ProgressiveMediaSource.Factory(dataSourceFactory)
                .createMediaSource(mediaItem);

        player = new ExoPlayer.Builder(this).build();
        playerView.setPlayer(player);
        player.addListener(new Player.Listener() {
            @Override
            public void onPlaybackStateChanged(int playbackState) {
                if (playbackState == Player.STATE_BUFFERING) {
                    progress.setVisibility(View.VISIBLE);
                } else if (playbackState == Player.STATE_READY) {
                    progress.setVisibility(View.GONE);
                    errorView.setVisibility(View.GONE);
                } else if (playbackState == Player.STATE_ENDED) {
                    progress.setVisibility(View.GONE);
                }
            }

            @Override
            public void onPlayerError(PlaybackException error) {
                progress.setVisibility(View.GONE);
                String detail = error.getErrorCodeName();
                if (error.getCause() != null && error.getCause().getMessage() != null) detail += " · " + error.getCause().getMessage();
                showError("Видеото не може да се пушти.\n" + NetworkClient.friendlyMessage(new Exception(detail)));
            }
        });
        player.setMediaSource(mediaSource);
        player.prepare();
        player.setPlayWhenReady(true);
    }

    private void showError(String message) {
        progress.setVisibility(View.GONE);
        errorView.setText(message);
        errorView.setVisibility(View.VISIBLE);
    }

    private void hideSystemUi() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }

    @Override
    protected void onResume() {
        super.onResume();
        hideSystemUi();
    }

    @Override
    protected void onStop() {
        super.onStop();
        releasePlayer();
    }

    @Override
    protected void onDestroy() {
        releasePlayer();
        super.onDestroy();
    }

    private void releasePlayer() {
        if (player != null) {
            player.release();
            player = null;
        }
        if (playerView != null) playerView.setPlayer(null);
    }

    private static String safe(String value) {
        return value == null ? "" : value.trim();
    }
}
