package world.torbesi.ademitvxtreme;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public final class MainActivity extends AppCompatActivity {
    private TextView statusView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        statusView = findViewById(R.id.tv_connection_status);
        Button enter = findViewById(R.id.btn_enter);
        enter.setOnClickListener(v -> {
            startActivity(new Intent(this, HomeActivity.class));
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        });
        checkConnection();
    }

    private void checkConnection() {
        statusView.setText("Се проверува серверот…");
        NetworkClient.IO.execute(() -> {
            try {
                Models.AuthResult auth = new XtreamApi(new XtreamConfig(this)).authenticate();
                runOnUiThread(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    statusView.setText(auth.authorized
                            ? "● ПОВРЗАНО · важи до " + auth.expires
                            : "● НЕАКТИВЕН ПРИСТАП");
                    statusView.setTextColor(auth.authorized ? 0xFFB9FF9D : 0xFFFF8E8E);
                });
            } catch (Exception error) {
                runOnUiThread(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    statusView.setText("● ОФЛАЈН · продолжете до поставките");
                    statusView.setTextColor(0xFFFFC56B);
                    statusView.setVisibility(View.VISIBLE);
                });
            }
        });
    }
}
