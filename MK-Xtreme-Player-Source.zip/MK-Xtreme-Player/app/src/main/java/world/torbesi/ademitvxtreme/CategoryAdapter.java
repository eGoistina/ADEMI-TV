package world.torbesi.ademitvxtreme;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public final class CategoryAdapter extends BaseAdapter {
    private final LayoutInflater inflater;
    private final List<Models.Category> items = new ArrayList<>();
    private int selectedPosition = -1;

    public CategoryAdapter(Context context) {
        inflater = LayoutInflater.from(context);
    }

    public void setItems(List<Models.Category> categories) {
        items.clear();
        if (categories != null) items.addAll(categories);
        if (selectedPosition >= items.size()) selectedPosition = -1;
        notifyDataSetChanged();
    }

    public Models.Category getCategory(int position) {
        return position >= 0 && position < items.size() ? items.get(position) : null;
    }

    public void setSelectedPosition(int position) {
        selectedPosition = position;
        notifyDataSetChanged();
    }

    @Override public int getCount() { return items.size(); }
    @Override public Object getItem(int position) { return getCategory(position); }
    @Override public long getItemId(int position) { return position; }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.item_category, parent, false);
            holder = new ViewHolder();
            holder.name = convertView.findViewById(R.id.tv_category_name);
            holder.count = convertView.findViewById(R.id.tv_category_count);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        Models.Category category = items.get(position);
        holder.name.setText(category.name);
        holder.count.setText(category.count > 0 ? String.valueOf(category.count) : "");
        holder.count.setVisibility(category.count > 0 ? View.VISIBLE : View.GONE);
        convertView.setActivated(position == selectedPosition);
        return convertView;
    }

    private static final class ViewHolder {
        TextView name;
        TextView count;
    }
}
