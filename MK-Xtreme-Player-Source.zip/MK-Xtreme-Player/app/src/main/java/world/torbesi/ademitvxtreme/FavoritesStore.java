package world.torbesi.ademitvxtreme;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.HashSet;
import java.util.Set;

public final class FavoritesStore {
    private static final String PREFS = "ademi_xtreme_favorites";
    private static final String KEY_SET = "favorite_keys";
    private final SharedPreferences preferences;

    public FavoritesStore(Context context) {
        preferences = context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public boolean isFavorite(Models.Stream stream) {
        return stream != null && getKeys().contains(stream.favoriteKey());
    }

    public boolean toggle(Models.Stream stream) {
        if (stream == null) return false;
        Set<String> keys = getKeys();
        boolean nowFavorite;
        if (keys.contains(stream.favoriteKey())) {
            keys.remove(stream.favoriteKey());
            nowFavorite = false;
        } else {
            keys.add(stream.favoriteKey());
            nowFavorite = true;
        }
        preferences.edit().putStringSet(KEY_SET, keys).apply();
        return nowFavorite;
    }

    public Set<String> getKeys() {
        Set<String> stored = preferences.getStringSet(KEY_SET, new HashSet<>());
        return new HashSet<>(stored == null ? new HashSet<>() : stored);
    }
}
