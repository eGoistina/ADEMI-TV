package world.torbesi.ademitvxtreme;

import java.util.ArrayList;
import java.util.List;

public final class Models {
    private Models() {}

    public enum MediaType {
        LIVE, VOD, SERIES, EPISODE
    }

    public static final class Category {
        public final String id;
        public final String name;
        public int count;
        public final boolean synthetic;

        public Category(String id, String name) {
            this(id, name, 0, false);
        }

        public Category(String id, String name, int count, boolean synthetic) {
            this.id = id == null ? "" : id;
            this.name = name == null ? "" : name;
            this.count = count;
            this.synthetic = synthetic;
        }

        @Override
        public String toString() {
            return name;
        }
    }

    public static final class Stream {
        public final String id;
        public final String name;
        public final String categoryId;
        public final String categoryName;
        public final String iconUrl;
        public final String extension;
        public final String directUrl;
        public final MediaType type;
        public final String parentId;
        public final int season;
        public final int episode;

        public Stream(
                String id,
                String name,
                String categoryId,
                String categoryName,
                String iconUrl,
                String extension,
                String directUrl,
                MediaType type) {
            this(id, name, categoryId, categoryName, iconUrl, extension, directUrl, type, "", 0, 0);
        }

        public Stream(
                String id,
                String name,
                String categoryId,
                String categoryName,
                String iconUrl,
                String extension,
                String directUrl,
                MediaType type,
                String parentId,
                int season,
                int episode) {
            this.id = id == null ? "" : id;
            this.name = name == null ? "" : name;
            this.categoryId = categoryId == null ? "" : categoryId;
            this.categoryName = categoryName == null ? "" : categoryName;
            this.iconUrl = iconUrl == null ? "" : iconUrl;
            this.extension = extension == null || extension.trim().isEmpty() ? "mp4" : extension;
            this.directUrl = directUrl == null ? "" : directUrl;
            this.type = type == null ? MediaType.LIVE : type;
            this.parentId = parentId == null ? "" : parentId;
            this.season = season;
            this.episode = episode;
        }

        public String favoriteKey() {
            return type.name() + ":" + id;
        }
    }

    public static final class EpgEntry {
        public final String title;
        public final String start;
        public final String end;

        public EpgEntry(String title, String start, String end) {
            this.title = title == null ? "" : title;
            this.start = start == null ? "" : start;
            this.end = end == null ? "" : end;
        }
    }

    public static final class AuthResult {
        public final boolean authorized;
        public final String status;
        public final String expires;
        public final String serverUrl;
        public final String message;

        public AuthResult(boolean authorized, String status, String expires, String serverUrl, String message) {
            this.authorized = authorized;
            this.status = status == null ? "" : status;
            this.expires = expires == null ? "" : expires;
            this.serverUrl = serverUrl == null ? "" : serverUrl;
            this.message = message == null ? "" : message;
        }
    }

    public static final class Playlist {
        public final List<Category> categories = new ArrayList<>();
        public final List<Stream> streams = new ArrayList<>();
    }
}
