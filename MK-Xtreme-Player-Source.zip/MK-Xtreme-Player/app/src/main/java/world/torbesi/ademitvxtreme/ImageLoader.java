package world.torbesi.ademitvxtreme;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.LruCache;
import android.widget.ImageView;

public final class ImageLoader {
    private static final LruCache<String, Bitmap> CACHE = new LruCache<String, Bitmap>(12 * 1024 * 1024) {
        @Override
        protected int sizeOf(String key, Bitmap value) {
            return value.getByteCount();
        }
    };

    private ImageLoader() {}

    public static void load(ImageView view, String url, int placeholder) {
        if (view == null) return;
        view.setTag(url == null ? "" : url);
        if (url == null || url.trim().isEmpty()) {
            view.setImageResource(placeholder);
            return;
        }
        Bitmap cached = CACHE.get(url);
        if (cached != null) {
            view.setImageBitmap(cached);
            return;
        }
        view.setImageResource(placeholder);
        NetworkClient.IO.execute(() -> {
            try {
                byte[] bytes = NetworkClient.getBytes(url, 5 * 1024 * 1024);
                Bitmap bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                if (bitmap == null) return;
                CACHE.put(url, bitmap);
                view.post(() -> {
                    Object tag = view.getTag();
                    if (tag != null && url.equals(tag.toString())) view.setImageBitmap(bitmap);
                });
            } catch (Exception ignored) {
            }
        });
    }
}
