package world.torbesi.ademitvxtreme;

import android.Manifest;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.view.KeyEvent;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;
import java.util.Locale;

public final class HomeActivity extends AppCompatActivity {
    private static final int REQUEST_SPEECH = 41;
    private static final int REQUEST_AUDIO = 42;

    private EditText searchInput;
    private TextView statusView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        searchInput = findViewById(R.id.et_home_search);
        statusView = findViewById(R.id.tv_home_status);

        findViewById(R.id.btn_macedonian).setOnClickListener(v -> openBrowser(Models.MediaType.LIVE, "MK", false, ""));
        findViewById(R.id.btn_serbian).setOnClickListener(v -> openBrowser(Models.MediaType.LIVE, "RS", false, ""));
        findViewById(R.id.btn_bosnian).setOnClickListener(v -> openBrowser(Models.MediaType.LIVE, "BA", false, ""));
        findViewById(R.id.btn_islamic).setOnClickListener(v -> openBrowser(Models.MediaType.LIVE, "ISLAM", false, ""));
        findViewById(R.id.btn_sports).setOnClickListener(v -> openBrowser(Models.MediaType.LIVE, "SPORT", false, ""));
        findViewById(R.id.btn_movies).setOnClickListener(v -> openBrowser(Models.MediaType.VOD, "DE", false, ""));

        findViewById(R.id.btn_all_tv).setOnClickListener(v -> openBrowser(Models.MediaType.LIVE, "", false, ""));
        findViewById(R.id.btn_video).setOnClickListener(v -> openBrowser(Models.MediaType.VOD, "", false, ""));
        findViewById(R.id.btn_series).setOnClickListener(v -> openBrowser(Models.MediaType.SERIES, "", false, ""));
        findViewById(R.id.btn_favorites).setOnClickListener(v -> openBrowser(Models.MediaType.LIVE, "", true, ""));
        findViewById(R.id.btn_settings).setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));

        findViewById(R.id.nav_search).setOnClickListener(v -> {
            searchInput.requestFocus();
            searchInput.selectAll();
        });
        findViewById(R.id.nav_favorites).setOnClickListener(v -> openBrowser(Models.MediaType.LIVE, "", true, ""));
        findViewById(R.id.nav_profile).setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));
        findViewById(R.id.btn_voice_search).setOnClickListener(v -> startVoiceSearch());

        searchInput.setOnEditorActionListener((v, actionId, event) -> {
            boolean enterPressed = event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER;
            if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH || enterPressed) {
                performSearch(searchInput.getText().toString());
                return true;
            }
            return false;
        });

        checkConnection();
    }

    @Override
    protected void onResume() {
        super.onResume();
        checkConnection();
    }

    private void performSearch(String query) {
        String clean = query == null ? "" : query.trim();
        if (clean.isEmpty()) {
            Toast.makeText(this, "Напишете име на канал", Toast.LENGTH_SHORT).show();
            return;
        }
        openBrowser(Models.MediaType.LIVE, "", false, clean);
    }

    private void openBrowser(Models.MediaType type, String filter, boolean favorites, String query) {
        Intent intent = new Intent(this, BrowserActivity.class);
        intent.putExtra(BrowserActivity.EXTRA_TYPE, type.name());
        intent.putExtra(BrowserActivity.EXTRA_FILTER, filter);
        intent.putExtra(BrowserActivity.EXTRA_FAVORITES, favorites);
        intent.putExtra(BrowserActivity.EXTRA_QUERY, query);
        startActivity(intent);
    }

    private void startVoiceSearch() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_AUDIO);
            return;
        }
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "mk-MK");
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Кажете го името на каналот");
        try {
            startActivityForResult(intent, REQUEST_SPEECH);
        } catch (ActivityNotFoundException error) {
            Toast.makeText(this, "Гласовното пребарување не е достапно", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_AUDIO && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startVoiceSearch();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_SPEECH && resultCode == RESULT_OK && data != null) {
            ArrayList<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (results != null && !results.isEmpty()) {
                String query = results.get(0);
                searchInput.setText(query);
                performSearch(query);
            }
        }
    }

    private void checkConnection() {
        statusView.setText("Серверот се проверува…");
        NetworkClient.IO.execute(() -> {
            try {
                Models.AuthResult auth = new XtreamApi(new XtreamConfig(this)).authenticate();
                runOnUiThread(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    statusView.setText(auth.authorized
                            ? ("M3U".equals(auth.status)
                                ? "● ПОВРЗАНО · M3U Plus · MPEG-TS"
                                : "● ПОВРЗАНО · Xtreme Codes · до " + auth.expires)
                            : "● ПРИСТАПОТ НЕ Е АКТИВЕН");
                    statusView.setTextColor(auth.authorized ? 0xFFB9FF9D : 0xFFFF8E8E);
                });
            } catch (Exception error) {
                runOnUiThread(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    statusView.setText("● НЕМА ВРСКА · проверете Поставки");
                    statusView.setTextColor(0xFFFFC56B);
                });
            }
        });
    }
}
