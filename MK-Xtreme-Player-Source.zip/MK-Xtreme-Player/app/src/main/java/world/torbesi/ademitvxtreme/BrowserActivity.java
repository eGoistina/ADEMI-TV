package world.torbesi.ademitvxtreme;

import android.Manifest;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class BrowserActivity extends AppCompatActivity {
    public static final String EXTRA_TYPE = "media_type";
    public static final String EXTRA_FILTER = "home_filter";
    public static final String EXTRA_FAVORITES = "favorites_only";
    public static final String EXTRA_QUERY = "initial_query";

    private static final int REQUEST_SPEECH = 71;
    private static final int REQUEST_AUDIO = 72;

    private XtreamConfig config;
    private XtreamApi api;
    private FavoritesStore favorites;

    private TextView titleView;
    private TextView statusView;
    private TextView streamHeader;
    private TextView selectedName;
    private TextView epgNow;
    private TextView epgNext;
    private ImageView previewLogo;
    private EditText searchInput;
    private ListView categoryList;
    private ListView streamList;
    private Button tabLive;
    private Button tabMovies;
    private Button tabSeries;
    private Button tabSports;
    private Button favoriteButton;

    private CategoryAdapter categoryAdapter;
    private StreamAdapter streamAdapter;

    private final List<Models.Category> categories = new ArrayList<>();
    private final List<Models.Stream> loadedStreams = new ArrayList<>();
    private final List<Models.Stream> visibleStreams = new ArrayList<>();
    private Map<String, String> categoryNames = new HashMap<>();

    private Models.MediaType currentType = Models.MediaType.LIVE;
    private String activeFilter = "";
    private boolean favoritesOnly;
    private String initialQuery = "";
    private boolean usingM3u;
    private Models.Playlist m3uPlaylist;
    private Models.Stream selectedStream;
    private Models.Stream selectedSeries;
    private boolean episodeMode;
    private List<Models.Stream> savedSeriesList;
    private int selectedCategoryPosition = -1;
    private int requestGeneration;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_browser);

        config = new XtreamConfig(this);
        api = new XtreamApi(config);
        favorites = new FavoritesStore(this);

        bindViews();
        setupAdapters();
        setupInteractions();

        String typeName = getIntent().getStringExtra(EXTRA_TYPE);
        try {
            currentType = Models.MediaType.valueOf(typeName == null ? Models.MediaType.LIVE.name() : typeName);
        } catch (Exception ignored) {
            currentType = Models.MediaType.LIVE;
        }
        if (currentType == Models.MediaType.EPISODE) currentType = Models.MediaType.SERIES;
        activeFilter = safe(getIntent().getStringExtra(EXTRA_FILTER));
        favoritesOnly = getIntent().getBooleanExtra(EXTRA_FAVORITES, false);
        initialQuery = safe(getIntent().getStringExtra(EXTRA_QUERY));
        if (!initialQuery.isEmpty()) searchInput.setText(initialQuery);

        updateTabs();
        loadCategories(false);

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override public void handleOnBackPressed() { handleBack(); }
        });
    }

    private void bindViews() {
        titleView = findViewById(R.id.tv_browser_title);
        statusView = findViewById(R.id.tv_loading_status);
        streamHeader = findViewById(R.id.tv_stream_header);
        selectedName = findViewById(R.id.tv_selected_name);
        epgNow = findViewById(R.id.tv_epg_now);
        epgNext = findViewById(R.id.tv_epg_next);
        previewLogo = findViewById(R.id.iv_preview_logo);
        searchInput = findViewById(R.id.et_browser_search);
        categoryList = findViewById(R.id.list_categories);
        streamList = findViewById(R.id.list_streams);
        tabLive = findViewById(R.id.tab_live);
        tabMovies = findViewById(R.id.tab_movies);
        tabSeries = findViewById(R.id.tab_series);
        tabSports = findViewById(R.id.tab_sports);
        favoriteButton = findViewById(R.id.btn_favorite);
    }

    private void setupAdapters() {
        categoryAdapter = new CategoryAdapter(this);
        streamAdapter = new StreamAdapter(this, favorites, (stream, favorite) -> {
            if (favoritesOnly && !favorite) applySearchFilter();
            if (stream == selectedStream) updateFavoriteButton();
        });
        categoryList.setAdapter(categoryAdapter);
        streamList.setAdapter(streamAdapter);
    }

    private void setupInteractions() {
        findViewById(R.id.btn_back).setOnClickListener(v -> handleBack());
        findViewById(R.id.btn_browser_voice).setOnClickListener(v -> startVoiceSearch());
        findViewById(R.id.btn_play).setOnClickListener(v -> playSelected());
        favoriteButton.setOnClickListener(v -> toggleSelectedFavorite());
        findViewById(R.id.btn_reload).setOnClickListener(v -> reloadCurrent());

        tabLive.setOnClickListener(v -> switchMode(Models.MediaType.LIVE, ""));
        tabMovies.setOnClickListener(v -> switchMode(Models.MediaType.VOD, ""));
        tabSeries.setOnClickListener(v -> switchMode(Models.MediaType.SERIES, ""));
        tabSports.setOnClickListener(v -> switchMode(Models.MediaType.LIVE, "SPORT"));

        categoryList.setOnItemClickListener((parent, view, position, id) -> {
            if (episodeMode) return;
            Models.Category category = categoryAdapter.getCategory(position);
            if (category == null) return;
            selectedCategoryPosition = position;
            categoryAdapter.setSelectedPosition(position);
            loadStreams(category, false);
        });

        streamList.setOnItemClickListener((parent, view, position, id) -> {
            Models.Stream stream = streamAdapter.getStream(position);
            if (stream == null) return;
            selectedStream = stream;
            streamAdapter.setSelectedPosition(position);
            updatePreview(stream);
        });

        streamList.setOnItemLongClickListener((parent, view, position, id) -> {
            Models.Stream stream = streamAdapter.getStream(position);
            if (stream == null) return false;
            boolean now = favorites.toggle(stream);
            streamAdapter.notifyDataSetChanged();
            Toast.makeText(this, now ? "Додадено во омилени" : "Отстрането од омилени", Toast.LENGTH_SHORT).show();
            return true;
        });

        searchInput.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { applySearchFilter(); }
            @Override public void afterTextChanged(Editable s) {}
        });
    }

    private void switchMode(Models.MediaType type, String filter) {
        if (episodeMode) exitEpisodeMode();
        currentType = type;
        activeFilter = safe(filter);
        favoritesOnly = false;
        usingM3u = false;
        m3uPlaylist = null;
        selectedStream = null;
        selectedSeries = null;
        searchInput.setText("");
        clearPreview();
        updateTabs();
        loadCategories(false);
    }

    private void updateTabs() {
        boolean sports = currentType == Models.MediaType.LIVE && "SPORT".equals(activeFilter);
        tabLive.setSelected(currentType == Models.MediaType.LIVE && !sports);
        tabMovies.setSelected(currentType == Models.MediaType.VOD);
        tabSeries.setSelected(currentType == Models.MediaType.SERIES);
        tabSports.setSelected(sports);
        if (episodeMode) {
            titleView.setText("Епизоди");
        } else if (sports) {
            titleView.setText("Спортски канали");
        } else if (favoritesOnly) {
            titleView.setText("Омилени");
        } else {
            titleView.setText(switch (currentType) {
                case LIVE -> filterTitle(activeFilter, "ТВ канали");
                case VOD -> filterTitle(activeFilter, "Филмови");
                case SERIES, EPISODE -> "Серии";
            });
        }
    }

    private String filterTitle(String filter, String fallback) {
        return switch (filter) {
            case "MK" -> "Македонски канали";
            case "RS" -> "Српски канали";
            case "BA" -> "Босански канали";
            case "ISLAM" -> "Исламски канали";
            case "SPORT" -> "Спортски канали";
            case "DE" -> "Германски филмови";
            default -> fallback;
        };
    }

    private void loadCategories(boolean force) {
        int generation = ++requestGeneration;
        setBusy("Се вчитуваат групите…");
        categories.clear();
        loadedStreams.clear();
        visibleStreams.clear();
        categoryAdapter.setItems(categories);
        streamAdapter.setItems(visibleStreams);
        NetworkClient.IO.execute(() -> {
            try {
                List<Models.Category> result;
                if (currentType == Models.MediaType.LIVE) {
                    try {
                        m3uPlaylist = api.getM3uPlaylist(force);
                        result = new ArrayList<>(m3uPlaylist.categories);
                        usingM3u = true;
                    } catch (Exception m3uError) {
                        result = api.getCategories(Models.MediaType.LIVE);
                        if (result.isEmpty()) throw m3uError;
                        usingM3u = false;
                    }
                } else {
                    result = api.getCategories(currentType);
                    usingM3u = false;
                }
                final List<Models.Category> categoriesForUi = new ArrayList<>(result);
                final Map<String, String> map = XtreamApi.categoryNameMap(categoriesForUi);
                runOnUiThread(() -> {
                    if (!validGeneration(generation)) return;
                    categoryNames = map;
                    buildVisibleCategories(categoriesForUi);
                });
            } catch (Exception error) {
                runOnUiThread(() -> {
                    if (!validGeneration(generation)) return;
                    showError("Не може да се вчита содржината: " + NetworkClient.friendlyMessage(error));
                });
            }
        });
    }

    private void buildVisibleCategories(List<Models.Category> source) {
        categories.clear();
        if (favoritesOnly) {
            categories.add(new Models.Category("__FAVORITES__", "Омилени", 0, true));
        } else if (!activeFilter.isEmpty()) {
            categories.add(new Models.Category("__FILTER__", filterTitle(activeFilter, "Избрани"), 0, true));
        } else {
            categories.add(new Models.Category("__ALL__", "Сите", 0, true));
            categories.addAll(source);
        }
        categoryAdapter.setItems(categories);
        if (categories.isEmpty()) {
            showError("Нема достапни групи.");
            return;
        }
        int autoPosition;
        if (favoritesOnly || !activeFilter.isEmpty() || !initialQuery.isEmpty()) {
            autoPosition = 0;
        } else {
            autoPosition = categories.size() > 1 ? 1 : 0;
        }
        selectedCategoryPosition = autoPosition;
        categoryAdapter.setSelectedPosition(autoPosition);
        categoryList.setSelection(autoPosition);
        loadStreams(categories.get(autoPosition), false);
    }

    private void loadStreams(Models.Category category, boolean force) {
        if (category == null) return;
        int generation = ++requestGeneration;
        setBusy("Се вчитува листата…");
        selectedStream = null;
        clearPreview();
        NetworkClient.IO.execute(() -> {
            try {
                List<Models.Stream> result;
                boolean requiresAll = category.synthetic || favoritesOnly || !activeFilter.isEmpty() || !initialQuery.isEmpty();
                String categoryId = requiresAll ? null : category.id;
                if (currentType == Models.MediaType.LIVE && usingM3u) {
                    if (m3uPlaylist == null || force) m3uPlaylist = api.getM3uPlaylist(force);
                    result = streamsFromM3u(categoryId);
                } else {
                    try {
                        result = api.getStreams(currentType, categoryId, categoryNames);
                        if (currentType == Models.MediaType.LIVE && result.isEmpty()) {
                            m3uPlaylist = api.getM3uPlaylist(force);
                            usingM3u = true;
                            result = streamsFromM3u(categoryId);
                        }
                    } catch (Exception apiError) {
                        if (currentType != Models.MediaType.LIVE) throw apiError;
                        m3uPlaylist = api.getM3uPlaylist(force);
                        usingM3u = true;
                        result = streamsFromM3u(categoryId);
                    }
                }
                List<Models.Stream> filtered = applyHomeFilter(result);
                runOnUiThread(() -> {
                    if (!validGeneration(generation)) return;
                    loadedStreams.clear();
                    loadedStreams.addAll(filtered);
                    initialQuery = "";
                    applySearchFilter();
                    setReady(loadedStreams.size());
                });
            } catch (Exception error) {
                runOnUiThread(() -> {
                    if (!validGeneration(generation)) return;
                    showError("Не може да се вчита листата: " + NetworkClient.friendlyMessage(error));
                });
            }
        });
    }


    private List<Models.Stream> streamsFromM3u(String categoryId) {
        List<Models.Stream> result = new ArrayList<>();
        if (m3uPlaylist == null) return result;
        for (Models.Stream stream : m3uPlaylist.streams) {
            if (categoryId == null || categoryId.equals(stream.categoryId)) result.add(stream);
        }
        return result;
    }

    private List<Models.Stream> applyHomeFilter(List<Models.Stream> source) {
        List<Models.Stream> result = new ArrayList<>();
        for (Models.Stream stream : source) {
            if (favoritesOnly && !favorites.isFavorite(stream)) continue;
            if (!activeFilter.isEmpty() && !matchesSection(stream, activeFilter)) continue;
            result.add(stream);
        }
        return result;
    }

    private boolean matchesSection(Models.Stream stream, String filter) {
        String value = stream.categoryName + " " + stream.name;
        return switch (filter) {
            case "MK" -> TextTools.matchesAny(value, "macedonia", "makedon", "македон", "mk ", "| mk", "мк ");
            case "RS" -> TextTools.matchesAny(value, "serbia", "serbian", "srbija", "srps", "срб", "rs ", "| rs");
            case "BA" -> TextTools.matchesAny(value, "bosnia", "bosanski", "bosna", "bih", "босан", "ba ", "| ba");
            case "ISLAM" -> TextTools.matchesAny(value, "islam", "muslim", "quran", "kuran", "ramazan", "meka", "medina", "ислам", "куран");
            case "SPORT" -> TextTools.matchesAny(value, "sport", "arena", "formula", "moto gp", "ppv", "football", "fudbal", "nogomet", "basket", "tenis", "ufc", "fight", "спорт", "фудбал");
            case "DE" -> matchesGermanCategory(stream.categoryName);
            default -> true;
        };
    }

    private boolean matchesGermanCategory(String categoryName) {
        String normalized = " " + TextTools.normalize(categoryName) + " ";
        return normalized.contains(" german ")
                || normalized.contains(" deutsch ")
                || normalized.contains(" germany ")
                || normalized.contains(" deutschland ")
                || normalized.contains(" de filme ")
                || normalized.contains(" de movies ")
                || normalized.startsWith(" de ")
                || normalized.contains("| de ");
    }

    private void applySearchFilter() {
        if (streamAdapter == null) return;
        String query = searchInput == null ? "" : searchInput.getText().toString();
        visibleStreams.clear();
        for (Models.Stream stream : loadedStreams) {
            if (favoritesOnly && !favorites.isFavorite(stream)) continue;
            if (TextTools.contains(stream.name + " " + stream.categoryName, query)) visibleStreams.add(stream);
        }
        streamAdapter.setItems(visibleStreams);
        streamHeader.setText((episodeMode ? "ЕПИЗОДИ" : streamLabel()) + " · " + visibleStreams.size());
        if (visibleStreams.isEmpty()) {
            selectedStream = null;
            clearPreview();
        }
    }

    private String streamLabel() {
        return switch (currentType) {
            case LIVE -> "КАНАЛИ";
            case VOD -> "ФИЛМОВИ";
            case SERIES, EPISODE -> "СЕРИИ";
        };
    }

    private void updatePreview(Models.Stream stream) {
        selectedName.setText(stream.name);
        ImageLoader.load(previewLogo, stream.iconUrl, R.drawable.ademi_logo_512);
        updateFavoriteButton();
        if (stream.type == Models.MediaType.LIVE && stream.directUrl.isEmpty() && !usingM3u) {
            epgNow.setText("Се вчитува програмата…");
            epgNext.setText("");
            String expectedKey = stream.favoriteKey();
            NetworkClient.IO.execute(() -> {
                try {
                    List<Models.EpgEntry> epg = api.getShortEpg(stream.id);
                    runOnUiThread(() -> {
                        if (selectedStream == null || !expectedKey.equals(selectedStream.favoriteKey())) return;
                        if (epg.isEmpty()) {
                            epgNow.setText("Нема достапна програма");
                            epgNext.setText("");
                        } else {
                            Models.EpgEntry now = epg.get(0);
                            epgNow.setText("Сега: " + now.title + timeRange(now));
                            if (epg.size() > 1) {
                                Models.EpgEntry next = epg.get(1);
                                epgNext.setText("Следно: " + next.title + timeRange(next));
                            } else {
                                epgNext.setText("");
                            }
                        }
                    });
                } catch (Exception ignored) {
                    runOnUiThread(() -> {
                        if (selectedStream != null && expectedKey.equals(selectedStream.favoriteKey())) {
                            epgNow.setText("Програма не е достапна");
                            epgNext.setText("");
                        }
                    });
                }
            });
        } else if (stream.type == Models.MediaType.SERIES) {
            epgNow.setText("Притиснете ПУШТИ за да ги отворите епизодите.");
            epgNext.setText("");
        } else if (stream.type == Models.MediaType.EPISODE) {
            epgNow.setText("Сезона " + stream.season + " · Епизода " + stream.episode);
            epgNext.setText("");
        } else {
            epgNow.setText(stream.type == Models.MediaType.VOD ? "Филм" : "Подготвено за пуштање");
            epgNext.setText("");
        }
    }

    private String timeRange(Models.EpgEntry entry) {
        if (entry.start.isEmpty() && entry.end.isEmpty()) return "";
        return " · " + entry.start + (entry.end.isEmpty() ? "" : "–" + entry.end);
    }

    private void playSelected() {
        if (selectedStream == null) {
            Toast.makeText(this, "Прво изберете канал или видео", Toast.LENGTH_SHORT).show();
            return;
        }
        if (selectedStream.type == Models.MediaType.SERIES) {
            loadEpisodes(selectedStream);
            return;
        }
        String url = config.playbackUrl(selectedStream);
        if (url.isEmpty()) {
            Toast.makeText(this, "Нема адреса за пуштање", Toast.LENGTH_LONG).show();
            return;
        }
        Intent intent = new Intent(this, PlayerActivity.class);
        intent.putExtra(PlayerActivity.EXTRA_URL, url);
        intent.putExtra(PlayerActivity.EXTRA_NAME, selectedStream.name);
        intent.putExtra(PlayerActivity.EXTRA_MEDIA_TYPE, selectedStream.type.name());
        startActivity(intent);
    }

    private void loadEpisodes(Models.Stream series) {
        int generation = ++requestGeneration;
        setBusy("Се вчитуваат епизодите…");
        NetworkClient.IO.execute(() -> {
            try {
                List<Models.Stream> episodes = api.getSeriesEpisodes(series);
                runOnUiThread(() -> {
                    if (!validGeneration(generation)) return;
                    if (episodes.isEmpty()) {
                        showError("Оваа серија нема достапни епизоди.");
                        return;
                    }
                    savedSeriesList = new ArrayList<>(loadedStreams);
                    selectedSeries = series;
                    episodeMode = true;
                    currentType = Models.MediaType.SERIES;
                    loadedStreams.clear();
                    loadedStreams.addAll(episodes);
                    searchInput.setText("");
                    categoryList.setEnabled(false);
                    titleView.setText(series.name);
                    updateTabs();
                    applySearchFilter();
                    setReady(episodes.size());
                });
            } catch (Exception error) {
                runOnUiThread(() -> {
                    if (!validGeneration(generation)) return;
                    showError("Не може да се вчитаат епизодите: " + NetworkClient.friendlyMessage(error));
                });
            }
        });
    }

    private void exitEpisodeMode() {
        if (!episodeMode) return;
        episodeMode = false;
        categoryList.setEnabled(true);
        loadedStreams.clear();
        if (savedSeriesList != null) loadedStreams.addAll(savedSeriesList);
        savedSeriesList = null;
        selectedStream = selectedSeries;
        selectedSeries = null;
        updateTabs();
        applySearchFilter();
        clearPreview();
    }

    private void toggleSelectedFavorite() {
        if (selectedStream == null) {
            Toast.makeText(this, "Прво изберете содржина", Toast.LENGTH_SHORT).show();
            return;
        }
        boolean now = favorites.toggle(selectedStream);
        streamAdapter.notifyDataSetChanged();
        updateFavoriteButton();
        Toast.makeText(this, now ? "Додадено во омилени" : "Отстрането од омилени", Toast.LENGTH_SHORT).show();
        if (favoritesOnly && !now) applySearchFilter();
    }

    private void updateFavoriteButton() {
        boolean favorite = favorites.isFavorite(selectedStream);
        favoriteButton.setText(favorite ? "★ ОМИЛЕН" : "♡ ОМИЛЕНИ");
        favoriteButton.setTextColor(favorite ? 0xFFFFD55A : 0xFFFFFFFF);
    }

    private void reloadCurrent() {
        if (episodeMode && selectedSeries != null) {
            loadEpisodes(selectedSeries);
            return;
        }
        Models.Category category = categoryAdapter.getCategory(selectedCategoryPosition);
        if (category == null) loadCategories(true); else loadStreams(category, true);
    }

    private void clearPreview() {
        selectedName.setText("Изберете содржина");
        epgNow.setText("Тековна програма");
        epgNext.setText("Следно");
        previewLogo.setImageResource(R.drawable.ademi_logo_512);
        updateFavoriteButton();
    }

    private void setBusy(String text) {
        statusView.setText(text);
        statusView.setTextColor(0xFFB9FF9D);
        statusView.setVisibility(View.VISIBLE);
    }

    private void setReady(int count) {
        statusView.setText((usingM3u ? "M3U Plus · MPEG-TS" : "Xtreme Codes API · TS Direct") + " · " + count + " ставки");
        statusView.setTextColor(0xFFB9FF9D);
        statusView.setVisibility(View.VISIBLE);
    }

    private void showError(String text) {
        statusView.setText(text);
        statusView.setTextColor(0xFFFF8E8E);
        statusView.setVisibility(View.VISIBLE);
        loadedStreams.clear();
        visibleStreams.clear();
        streamAdapter.setItems(visibleStreams);
        streamHeader.setText(streamLabel() + " · 0");
    }

    private boolean validGeneration(int generation) {
        return generation == requestGeneration && !isFinishing() && !isDestroyed();
    }

    private void startVoiceSearch() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_AUDIO);
            return;
        }
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "mk-MK");
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Кажете го името на каналот");
        try {
            startActivityForResult(intent, REQUEST_SPEECH);
        } catch (ActivityNotFoundException error) {
            Toast.makeText(this, "Гласовното пребарување не е достапно", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_AUDIO && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) startVoiceSearch();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_SPEECH && resultCode == RESULT_OK && data != null) {
            ArrayList<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (results != null && !results.isEmpty()) searchInput.setText(results.get(0));
        }
    }

    private void handleBack() {
        if (episodeMode) {
            exitEpisodeMode();
        } else {
            finish();
        }
    }

    private static String safe(String value) {
        return value == null ? "" : value.trim();
    }
}
