package world.torbesi.ademitvxtreme;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.StringReader;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class M3uParser {
    private static final Pattern ATTRIBUTE = Pattern.compile("([A-Za-z0-9_-]+)=\"([^\"]*)\"");

    private M3uParser() {}

    public static Models.Playlist parse(String body) throws IOException {
        Models.Playlist playlist = new Models.Playlist();
        Map<String, Models.Category> categoryMap = new LinkedHashMap<>();
        String pendingName = "";
        String pendingGroup = "Друго";
        String pendingLogo = "";
        String pendingId = "";
        int generatedId = 1;

        try (BufferedReader reader = new BufferedReader(new StringReader(body == null ? "" : body))) {
            String raw;
            while ((raw = reader.readLine()) != null) {
                String line = raw.trim();
                if (line.isEmpty() || line.equals("#EXTM3U")) continue;
                if (line.startsWith("#EXTINF")) {
                    int comma = line.indexOf(',');
                    pendingName = comma >= 0 ? line.substring(comma + 1).trim() : "Канал " + generatedId;
                    pendingGroup = attribute(line, "group-title");
                    if (pendingGroup.isEmpty()) pendingGroup = "Друго";
                    pendingLogo = attribute(line, "tvg-logo");
                    pendingId = attribute(line, "tvg-id");
                    continue;
                }
                if (line.startsWith("#")) continue;
                if (line.startsWith("http://") || line.startsWith("https://")) {
                    String categoryId = stableCategoryId(pendingGroup);
                    Models.Category category = categoryMap.get(categoryId);
                    if (category == null) {
                        category = new Models.Category(categoryId, pendingGroup, 0, false);
                        categoryMap.put(categoryId, category);
                    }
                    category.count++;
                    String streamId = pendingId.isEmpty() ? String.valueOf(generatedId) : pendingId;
                    playlist.streams.add(new Models.Stream(
                            streamId,
                            pendingName.isEmpty() ? "Канал " + generatedId : pendingName,
                            categoryId,
                            pendingGroup,
                            pendingLogo,
                            "ts",
                            line,
                            Models.MediaType.LIVE));
                    generatedId++;
                    pendingName = "";
                    pendingGroup = "Друго";
                    pendingLogo = "";
                    pendingId = "";
                }
            }
        }
        playlist.categories.addAll(categoryMap.values());
        return playlist;
    }

    private static String attribute(String line, String key) {
        Matcher matcher = ATTRIBUTE.matcher(line);
        while (matcher.find()) {
            if (key.equalsIgnoreCase(matcher.group(1))) return matcher.group(2).trim();
        }
        return "";
    }

    private static String stableCategoryId(String name) {
        return "m3u_" + Integer.toHexString((name == null ? "" : name.toLowerCase()).hashCode());
    }
}
