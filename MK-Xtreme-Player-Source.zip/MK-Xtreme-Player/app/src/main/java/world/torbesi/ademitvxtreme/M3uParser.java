package world.torbesi.ademitvxtreme;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.StringReader;
import java.net.URI;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class M3uParser {
    private static final Pattern QUOTED_ATTRIBUTE = Pattern.compile("([A-Za-z0-9_-]+)\\s*=\\s*\"([^\"]*)\"");
    private static final Pattern PLAIN_ATTRIBUTE = Pattern.compile("([A-Za-z0-9_-]+)\\s*=\\s*([^\\s,]+)");

    private M3uParser() {}

    public static Models.Playlist parse(String body) throws IOException {
        Models.Playlist playlist = new Models.Playlist();
        Map<String, Models.Category> categoryMap = new LinkedHashMap<>();
        String pendingName = "";
        String pendingGroup = "Друго";
        String pendingLogo = "";
        String pendingId = "";
        int generatedId = 1;

        String normalizedBody = stripBomAndLeadingWhitespace(body == null ? "" : body);
        try (BufferedReader reader = new BufferedReader(new StringReader(normalizedBody))) {
            String raw;
            while ((raw = reader.readLine()) != null) {
                String line = raw.trim();
                if (line.isEmpty() || line.equalsIgnoreCase("#EXTM3U")) continue;

                if (line.regionMatches(true, 0, "#EXTINF", 0, 7)) {
                    int comma = line.indexOf(',');
                    pendingName = comma >= 0 ? line.substring(comma + 1).trim() : "Канал " + generatedId;
                    pendingGroup = attribute(line, "group-title");
                    if (pendingGroup.isEmpty()) pendingGroup = "Друго";
                    pendingLogo = attribute(line, "tvg-logo");
                    pendingId = attribute(line, "tvg-id");
                    continue;
                }

                if (line.regionMatches(true, 0, "#EXTGRP:", 0, 8)) {
                    String group = line.substring(8).trim();
                    if (!group.isEmpty()) pendingGroup = group;
                    continue;
                }

                if (line.startsWith("#")) continue;
                if (!isSupportedUrl(line)) continue;

                String categoryId = stableCategoryId(pendingGroup);
                Models.Category category = categoryMap.get(categoryId);
                if (category == null) {
                    category = new Models.Category(categoryId, pendingGroup, 0, false);
                    categoryMap.put(categoryId, category);
                }
                category.count++;

                String streamId = pendingId.isEmpty()
                        ? "m3u_" + Integer.toHexString(line.hashCode())
                        : pendingId;
                String extension = detectExtension(line);
                playlist.streams.add(new Models.Stream(
                        streamId,
                        pendingName.isEmpty() ? "Канал " + generatedId : pendingName,
                        categoryId,
                        pendingGroup,
                        pendingLogo,
                        extension,
                        line,
                        Models.MediaType.LIVE));

                generatedId++;
                pendingName = "";
                pendingGroup = "Друго";
                pendingLogo = "";
                pendingId = "";
            }
        }

        playlist.categories.addAll(categoryMap.values());
        return playlist;
    }

    private static String attribute(String line, String key) {
        Matcher quoted = QUOTED_ATTRIBUTE.matcher(line);
        while (quoted.find()) {
            if (key.equalsIgnoreCase(quoted.group(1))) return quoted.group(2).trim();
        }
        Matcher plain = PLAIN_ATTRIBUTE.matcher(line);
        while (plain.find()) {
            if (key.equalsIgnoreCase(plain.group(1))) return plain.group(2).trim();
        }
        return "";
    }

    private static boolean isSupportedUrl(String line) {
        String lower = line.toLowerCase(Locale.ROOT);
        return lower.startsWith("http://") || lower.startsWith("https://");
    }

    private static String detectExtension(String url) {
        try {
            String path = new URI(url).getPath();
            if (path != null) {
                int dot = path.lastIndexOf('.');
                if (dot >= 0 && dot + 1 < path.length()) {
                    String ext = path.substring(dot + 1).toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]", "");
                    if (!ext.isEmpty() && ext.length() <= 6) return ext;
                }
            }
        } catch (Exception ignored) {}
        return "ts";
    }

    private static String stableCategoryId(String name) {
        String normalized = name == null ? "" : name.trim().toLowerCase(Locale.ROOT);
        return "m3u_" + Integer.toHexString(normalized.hashCode());
    }

    private static String stripBomAndLeadingWhitespace(String value) {
        int start = 0;
        while (start < value.length()) {
            char c = value.charAt(start);
            if (c == '\uFEFF' || Character.isWhitespace(c)) start++; else break;
        }
        return start == 0 ? value : value.substring(start);
    }
}
