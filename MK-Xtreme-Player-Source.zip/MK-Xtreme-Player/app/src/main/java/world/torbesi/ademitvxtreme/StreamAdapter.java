package world.torbesi.ademitvxtreme;

import android.content.Context;
import android.graphics.PorterDuff;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public final class StreamAdapter extends BaseAdapter {
    public interface FavoriteListener {
        void onFavoriteChanged(Models.Stream stream, boolean favorite);
    }

    private final LayoutInflater inflater;
    private final FavoritesStore favorites;
    private final FavoriteListener favoriteListener;
    private final List<Models.Stream> items = new ArrayList<>();
    private int selectedPosition = -1;

    public StreamAdapter(Context context, FavoritesStore favorites, FavoriteListener favoriteListener) {
        this.inflater = LayoutInflater.from(context);
        this.favorites = favorites;
        this.favoriteListener = favoriteListener;
    }

    public void setItems(List<Models.Stream> streams) {
        items.clear();
        if (streams != null) items.addAll(streams);
        if (selectedPosition >= items.size()) selectedPosition = -1;
        notifyDataSetChanged();
    }

    public Models.Stream getStream(int position) {
        return position >= 0 && position < items.size() ? items.get(position) : null;
    }

    public void setSelectedPosition(int position) {
        selectedPosition = position;
        notifyDataSetChanged();
    }

    @Override public int getCount() { return items.size(); }
    @Override public Object getItem(int position) { return getStream(position); }
    @Override public long getItemId(int position) { return position; }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.item_stream, parent, false);
            holder = new ViewHolder();
            holder.number = convertView.findViewById(R.id.tv_stream_number);
            holder.logo = convertView.findViewById(R.id.iv_stream_logo);
            holder.name = convertView.findViewById(R.id.tv_stream_name);
            holder.favorite = convertView.findViewById(R.id.iv_stream_favorite);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        Models.Stream stream = items.get(position);
        holder.number.setText(String.valueOf(position + 1));
        holder.name.setText(stream.name);
        ImageLoader.load(holder.logo, stream.iconUrl, R.drawable.ademi_logo_512);
        updateFavoriteIcon(holder.favorite, favorites.isFavorite(stream));
        holder.favorite.setOnClickListener(v -> {
            boolean nowFavorite = favorites.toggle(stream);
            updateFavoriteIcon(holder.favorite, nowFavorite);
            if (favoriteListener != null) favoriteListener.onFavoriteChanged(stream, nowFavorite);
        });
        convertView.setActivated(position == selectedPosition);
        return convertView;
    }

    private static void updateFavoriteIcon(ImageView image, boolean favorite) {
        int color = favorite ? 0xFFFFD55A : 0xFF87968B;
        image.setColorFilter(color, PorterDuff.Mode.SRC_IN);
        image.setAlpha(favorite ? 1f : 0.8f);
    }

    private static final class ViewHolder {
        TextView number;
        ImageView logo;
        TextView name;
        ImageView favorite;
    }
}
