package world.torbesi.ademitvxtreme;

import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class XtreamApi {
    private final XtreamConfig config;
    private Models.Playlist cachedM3u;

    public XtreamApi(XtreamConfig config) {
        this.config = config;
    }

    public Models.AuthResult authenticate() throws Exception {
        NetworkClient.Response response = NetworkClient.getText(config.playerApiUrl());
        JSONObject root = new JSONObject(response.body);
        JSONObject user = root.optJSONObject("user_info");
        JSONObject server = root.optJSONObject("server_info");
        if (user == null) {
            throw new IOException("Серверот не врати Xtreme Codes user_info");
        }
        boolean auth = user.optInt("auth", 0) == 1;
        String status = user.optString("status", auth ? "Active" : "Unauthorized");
        String expires = formatEpoch(user.optString("exp_date", ""));
        String serverUrl = "";
        if (server != null) {
            String protocol = server.optString("server_protocol", "http");
            String host = server.optString("url", "");
            String port = server.optString("port", "");
            if (!host.isEmpty()) {
                serverUrl = protocol + "://" + host + (port.isEmpty() || "80".equals(port) ? "" : ":" + port);
            }
        }
        String message = auth ? "Поврзано" : "Пристапот не е активен";
        return new Models.AuthResult(auth, status, expires, serverUrl, message);
    }

    public List<Models.Category> getCategories(Models.MediaType type) throws Exception {
        String action = switch (type) {
            case LIVE -> "get_live_categories";
            case VOD -> "get_vod_categories";
            case SERIES, EPISODE -> "get_series_categories";
        };
        NetworkClient.Response response = NetworkClient.getText(config.actionUrl(action));
        JSONArray array = new JSONArray(response.body);
        List<Models.Category> result = new ArrayList<>();
        for (int i = 0; i < array.length(); i++) {
            JSONObject item = array.optJSONObject(i);
            if (item == null) continue;
            String id = item.optString("category_id", String.valueOf(i));
            String name = item.optString("category_name", "Група " + (i + 1));
            result.add(new Models.Category(id, name));
        }
        return result;
    }

    public List<Models.Stream> getStreams(Models.MediaType type, String categoryId, Map<String, String> categoryNames) throws Exception {
        String action = switch (type) {
            case LIVE -> "get_live_streams";
            case VOD -> "get_vod_streams";
            case SERIES, EPISODE -> "get_series";
        };
        String url = config.actionUrl(action);
        if (categoryId != null && !categoryId.trim().isEmpty()) {
            url += "&category_id=" + java.net.URLEncoder.encode(categoryId, "UTF-8");
        }
        NetworkClient.Response response = NetworkClient.getText(url);
        JSONArray array = new JSONArray(response.body);
        List<Models.Stream> result = new ArrayList<>();
        for (int i = 0; i < array.length(); i++) {
            JSONObject item = array.optJSONObject(i);
            if (item == null) continue;
            String id;
            String icon;
            String extension;
            Models.MediaType actualType;
            if (type == Models.MediaType.SERIES || type == Models.MediaType.EPISODE) {
                id = item.optString("series_id", "");
                icon = firstNonEmpty(item.optString("cover", ""), item.optString("stream_icon", ""));
                extension = "mp4";
                actualType = Models.MediaType.SERIES;
            } else {
                id = item.optString("stream_id", "");
                icon = item.optString("stream_icon", "");
                extension = item.optString("container_extension", type == Models.MediaType.LIVE ? "ts" : "mp4");
                actualType = type;
            }
            if (id.isEmpty()) continue;
            String name = item.optString("name", "Без име");
            String catId = item.optString("category_id", categoryId == null ? "" : categoryId);
            String catName = categoryNames == null ? "" : categoryNames.getOrDefault(catId, "");
            result.add(new Models.Stream(id, name, catId, catName, icon, extension, "", actualType));
        }
        return result;
    }

    public List<Models.Stream> getSeriesEpisodes(Models.Stream series) throws Exception {
        if (series == null || series.id.isEmpty()) return new ArrayList<>();
        NetworkClient.Response response = NetworkClient.getText(
                config.actionUrl("get_series_info", "series_id", series.id));
        JSONObject root = new JSONObject(response.body);
        JSONObject episodes = root.optJSONObject("episodes");
        List<Models.Stream> result = new ArrayList<>();
        if (episodes == null) return result;
        List<String> seasons = new ArrayList<>();
        Iterator<String> keys = episodes.keys();
        while (keys.hasNext()) seasons.add(keys.next());
        seasons.sort((a, b) -> Integer.compare(parseInt(a), parseInt(b)));
        for (String seasonKey : seasons) {
            JSONArray seasonArray = episodes.optJSONArray(seasonKey);
            if (seasonArray == null) continue;
            int seasonNo = parseInt(seasonKey);
            for (int i = 0; i < seasonArray.length(); i++) {
                JSONObject episode = seasonArray.optJSONObject(i);
                if (episode == null) continue;
                String id = episode.optString("id", episode.optString("stream_id", ""));
                if (id.isEmpty()) continue;
                int episodeNo = episode.optInt("episode_num", i + 1);
                String title = episode.optString("title", "");
                if (title.isEmpty()) title = "Сезона " + seasonNo + " · Епизода " + episodeNo;
                String extension = episode.optString("container_extension", "mp4");
                JSONObject info = episode.optJSONObject("info");
                String icon = info == null ? series.iconUrl : firstNonEmpty(
                        info.optString("movie_image", ""),
                        info.optString("cover_big", ""),
                        series.iconUrl);
                result.add(new Models.Stream(
                        id,
                        title,
                        series.categoryId,
                        series.categoryName,
                        icon,
                        extension,
                        "",
                        Models.MediaType.EPISODE,
                        series.id,
                        seasonNo,
                        episodeNo));
            }
        }
        return result;
    }

    public List<Models.EpgEntry> getShortEpg(String streamId) throws Exception {
        String url = config.actionUrl("get_short_epg", "stream_id", streamId) + "&limit=2";
        NetworkClient.Response response = NetworkClient.getText(url);
        JSONObject root = new JSONObject(response.body);
        JSONArray listings = root.optJSONArray("epg_listings");
        List<Models.EpgEntry> result = new ArrayList<>();
        if (listings == null) return result;
        for (int i = 0; i < listings.length() && i < 2; i++) {
            JSONObject item = listings.optJSONObject(i);
            if (item == null) continue;
            String title = decodeMaybeBase64(item.optString("title", ""));
            String start = firstNonEmpty(item.optString("start", ""), item.optString("start_timestamp", ""));
            String end = firstNonEmpty(item.optString("end", ""), item.optString("stop_timestamp", ""));
            result.add(new Models.EpgEntry(title, trimDate(start), trimDate(end)));
        }
        return result;
    }

    public synchronized Models.Playlist getM3uPlaylist(boolean forceRefresh) throws Exception {
        if (!forceRefresh && cachedM3u != null && !cachedM3u.streams.isEmpty()) return cachedM3u;
        NetworkClient.Response response = NetworkClient.getText(config.playlistUrl());
        if (!response.body.trim().startsWith("#EXTM3U")) {
            throw new IOException("Серверот не врати M3U Plus листа");
        }
        cachedM3u = M3uParser.parse(response.body);
        return cachedM3u;
    }

    public static Map<String, String> categoryNameMap(List<Models.Category> categories) {
        Map<String, String> result = new HashMap<>();
        if (categories != null) {
            for (Models.Category category : categories) result.put(category.id, category.name);
        }
        return result;
    }

    private static String firstNonEmpty(String... values) {
        for (String value : values) if (value != null && !value.trim().isEmpty()) return value;
        return "";
    }

    private static int parseInt(String value) {
        try { return Integer.parseInt(value); } catch (Exception e) { return 0; }
    }

    private static String formatEpoch(String value) {
        try {
            long seconds = Long.parseLong(value);
            if (seconds <= 0) return "Неограничено";
            return new SimpleDateFormat("dd.MM.yyyy", Locale.GERMANY).format(new Date(seconds * 1000L));
        } catch (Exception e) {
            return value == null ? "" : value;
        }
    }

    private static String decodeMaybeBase64(String value) {
        if (value == null || value.trim().isEmpty()) return "";
        try {
            byte[] decoded = Base64.decode(value, Base64.DEFAULT);
            String text = new String(decoded, java.nio.charset.StandardCharsets.UTF_8).trim();
            if (!text.isEmpty() && printableRatio(text) > 0.8) return text;
        } catch (Exception ignored) {}
        return value;
    }

    private static double printableRatio(String text) {
        if (text.isEmpty()) return 0;
        int printable = 0;
        for (int i = 0; i < text.length(); i++) if (!Character.isISOControl(text.charAt(i))) printable++;
        return (double) printable / text.length();
    }

    private static String trimDate(String value) {
        if (value == null) return "";
        String text = value.trim();
        if (text.length() >= 16 && text.charAt(4) == '-') return text.substring(11, 16);
        return text;
    }
}
