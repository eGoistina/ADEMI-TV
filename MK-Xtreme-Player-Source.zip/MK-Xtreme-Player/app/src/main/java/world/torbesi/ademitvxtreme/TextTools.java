package world.torbesi.ademitvxtreme;

import java.text.Normalizer;
import java.util.Locale;

public final class TextTools {
    private TextTools() {}

    public static String normalize(String value) {
        if (value == null) return "";
        String text = Normalizer.normalize(value, Normalizer.Form.NFD)
                .replaceAll("\\p{M}+", "")
                .toLowerCase(Locale.ROOT)
                .replace('ѓ', 'г')
                .replace('ќ', 'к')
                .replace('č', 'c')
                .replace('ć', 'c')
                .replace('š', 's')
                .replace('ž', 'z')
                .replace('đ', 'd')
                .replaceAll("[^a-z0-9а-я]+", " ")
                .trim();
        return text.replaceAll("\\s+", " ");
    }

    public static boolean contains(String value, String query) {
        String normalizedQuery = normalize(query);
        return normalizedQuery.isEmpty() || normalize(value).contains(normalizedQuery);
    }

    public static boolean matchesAny(String value, String... keywords) {
        String normalized = normalize(value);
        for (String keyword : keywords) {
            if (normalized.contains(normalize(keyword))) return true;
        }
        return false;
    }
}
