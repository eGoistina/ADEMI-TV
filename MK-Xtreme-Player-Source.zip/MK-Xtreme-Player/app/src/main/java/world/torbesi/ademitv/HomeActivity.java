package world.torbesi.ademitv;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class HomeActivity extends AppCompatActivity {
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private TextView account;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        applyInsets(findViewById(R.id.homeRoot));

        account = findViewById(R.id.accountText);
        account.setText("Се поврзува со ТВ серверот…");

        bind(R.id.macedonianButton, AppData.SECTION_MACEDONIAN, "Македонски", "mk-MK");
        bind(R.id.serbianButton, AppData.SECTION_SERBIAN, "Српски", "sr-RS");
        bind(R.id.bosnianButton, AppData.SECTION_BOSNIAN, "Босански", "bs-BA");
        bind(R.id.islamicButton, AppData.SECTION_ISLAMIC, "Исламски", "mk-MK");
        bind(R.id.sportsButton, AppData.SECTION_SPORTS, "Спортски", "mk-MK");
        bind(R.id.moviesButton, AppData.SECTION_GERMAN_MOVIES, "Германски филмови", "de-DE");

        Button favorites = findViewById(R.id.favoritesButton);
        favorites.setOnClickListener(v -> {
            Intent intent = new Intent(this, BrowseActivity.class);
            intent.putExtra("favorites", true);
            intent.putExtra("title", "Омилени");
            intent.putExtra("voice_language", "mk-MK");
            startActivity(intent);
        });

        Button refresh = findViewById(R.id.logoutButton);
        refresh.setText("ПРОВЕРИ ЈА ВРСКАТА");
        refresh.setOnClickListener(v -> {
            AppData.clearPlaylistCache();
            testConnection(true);
        });

        testConnection(false);
    }

    private void testConnection(boolean showToast) {
        account.setText("Се поврзува со ТВ серверот…");
        executor.execute(() -> {
            try {
                int count = AppData.preloadPlaylist();
                runOnUiThread(() -> {
                    account.setText("● ПОВРЗАНО · " + count + " ставки се вчитани");
                    if (showToast) Toast.makeText(this, "Врската со серверот е успешна.", Toast.LENGTH_LONG).show();
                });
            } catch (Exception error) {
                String message = AppData.friendlyError(error);
                runOnUiThread(() -> {
                    account.setText("● НЕ Е ПОВРЗАНО\n" + message);
                    if (showToast) Toast.makeText(this, message, Toast.LENGTH_LONG).show();
                });
            }
        });
    }

    private void applyInsets(android.view.View root) {
        int left = root.getPaddingLeft();
        int top = root.getPaddingTop();
        int right = root.getPaddingRight();
        int bottom = root.getPaddingBottom();
        ViewCompat.setOnApplyWindowInsetsListener(root, (view, insets) -> {
            androidx.core.graphics.Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            view.setPadding(left + bars.left, top + bars.top, right + bars.right, bottom + bars.bottom);
            return insets;
        });
        ViewCompat.requestApplyInsets(root);
    }

    private void bind(int buttonId, String section, String title, String voiceLanguage) {
        findViewById(buttonId).setOnClickListener(v -> {
            Intent intent = new Intent(this, BrowseActivity.class);
            intent.putExtra("section", section);
            intent.putExtra("title", title);
            intent.putExtra("voice_language", voiceLanguage);
            startActivity(intent);
        });
    }

    @Override
    protected void onDestroy() {
        executor.shutdownNow();
        super.onDestroy();
    }
}
