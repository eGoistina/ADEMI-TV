package world.torbesi.ademitv;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class HomeActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (!AppData.hasLogin(this)) {
            openLogin();
            return;
        }
        setContentView(R.layout.activity_home);

        TextView account = findViewById(R.id.accountText);
        account.setText("Корисник: " + AppData.username(this));

        bind(R.id.macedonianButton, AppData.SECTION_MACEDONIAN, "Македонски", "mk-MK");
        bind(R.id.serbianButton, AppData.SECTION_SERBIAN, "Српски", "sr-RS");
        bind(R.id.bosnianButton, AppData.SECTION_BOSNIAN, "Босански", "bs-BA");
        bind(R.id.islamicButton, AppData.SECTION_ISLAMIC, "Исламски", "mk-MK");
        bind(R.id.sportsButton, AppData.SECTION_SPORTS, "Спортски", "mk-MK");
        bind(R.id.moviesButton, AppData.SECTION_GERMAN_MOVIES, "Германски филмови", "de-DE");

        Button favorites = findViewById(R.id.favoritesButton);
        favorites.setOnClickListener(v -> {
            Intent intent = new Intent(this, BrowseActivity.class);
            intent.putExtra("favorites", true);
            intent.putExtra("title", "Омилени");
            intent.putExtra("voice_language", "mk-MK");
            startActivity(intent);
        });

        Button logout = findViewById(R.id.logoutButton);
        logout.setOnClickListener(v -> {
            AppData.clearLogin(this);
            openLogin();
        });
    }

    private void bind(int buttonId, String section, String title, String voiceLanguage) {
        findViewById(buttonId).setOnClickListener(v -> {
            Intent intent = new Intent(this, BrowseActivity.class);
            intent.putExtra("section", section);
            intent.putExtra("title", title);
            intent.putExtra("voice_language", voiceLanguage);
            startActivity(intent);
        });
    }

    private void openLogin() {
        startActivity(new Intent(this, MainActivity.class));
        finish();
    }
}
