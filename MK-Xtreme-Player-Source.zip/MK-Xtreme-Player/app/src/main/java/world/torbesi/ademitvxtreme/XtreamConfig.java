package world.torbesi.ademitvxtreme;

import android.content.Context;
import android.content.SharedPreferences;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

public final class XtreamConfig {
    private static final String PREFS = "ademi_xtreme_config";
    private static final String KEY_SERVER = "server";
    private static final String KEY_USERNAME = "username";
    private static final String KEY_PASSWORD = "password";
    private static final String KEY_CONFIG_VERSION = "config_version";
    private static final int CURRENT_CONFIG_VERSION = 310;

    public static final String DEFAULT_SERVER = "http://line.queen-4k.cc";
    public static final String DEFAULT_USERNAME = "482075061933200";
    public static final String DEFAULT_PASSWORD = "403703471074612";
    public static final String DEFAULT_PLAYLIST_URL = "http://line.queen-4k.cc/get.php?username=482075061933200&password=403703471074612&type=m3u_plus&output=mpegts";

    private final Context context;

    public XtreamConfig(Context context) {
        this.context = context.getApplicationContext();
        migrateBuiltInAccess();
    }

    private void migrateBuiltInAccess() {
        SharedPreferences preferences = prefs();
        if (preferences.getInt(KEY_CONFIG_VERSION, 0) >= CURRENT_CONFIG_VERSION) return;
        preferences.edit()
                .putString(KEY_SERVER, DEFAULT_SERVER)
                .putString(KEY_USERNAME, DEFAULT_USERNAME)
                .putString(KEY_PASSWORD, DEFAULT_PASSWORD)
                .putInt(KEY_CONFIG_VERSION, CURRENT_CONFIG_VERSION)
                .apply();
    }

    private SharedPreferences prefs() {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public String getServer() {
        return normalizeServer(prefs().getString(KEY_SERVER, DEFAULT_SERVER));
    }

    public String getUsername() {
        return prefs().getString(KEY_USERNAME, DEFAULT_USERNAME).trim();
    }

    public String getPassword() {
        return prefs().getString(KEY_PASSWORD, DEFAULT_PASSWORD).trim();
    }

    public void save(String server, String username, String password) {
        prefs().edit()
                .putString(KEY_SERVER, normalizeServer(server))
                .putString(KEY_USERNAME, username == null ? "" : username.trim())
                .putString(KEY_PASSWORD, password == null ? "" : password.trim())
                .putInt(KEY_CONFIG_VERSION, CURRENT_CONFIG_VERSION)
                .apply();
    }

    public void restoreDefaults() {
        save(DEFAULT_SERVER, DEFAULT_USERNAME, DEFAULT_PASSWORD);
    }

    public String playerApiUrl() {
        return getServer() + "/player_api.php?username=" + enc(getUsername()) + "&password=" + enc(getPassword());
    }

    public String actionUrl(String action) {
        return playerApiUrl() + "&action=" + enc(action);
    }

    public String actionUrl(String action, String key, String value) {
        return actionUrl(action) + "&" + enc(key) + "=" + enc(value);
    }

    public String playlistUrl() {
        if (DEFAULT_SERVER.equals(getServer())
                && DEFAULT_USERNAME.equals(getUsername())
                && DEFAULT_PASSWORD.equals(getPassword())) {
            return DEFAULT_PLAYLIST_URL;
        }
        return getServer() + "/get.php?username=" + enc(getUsername())
                + "&password=" + enc(getPassword())
                + "&type=m3u_plus&output=mpegts";
    }

    Context appContext() {
        return context;
    }

    public String liveUrl(String streamId) {
        return getServer() + "/live/" + encPath(getUsername()) + "/" + encPath(getPassword()) + "/" + encPath(streamId) + ".ts";
    }

    public String vodUrl(String streamId, String extension) {
        String ext = sanitizeExtension(extension, "mp4");
        return getServer() + "/movie/" + encPath(getUsername()) + "/" + encPath(getPassword()) + "/" + encPath(streamId) + "." + ext;
    }

    public String seriesUrl(String episodeId, String extension) {
        String ext = sanitizeExtension(extension, "mp4");
        return getServer() + "/series/" + encPath(getUsername()) + "/" + encPath(getPassword()) + "/" + encPath(episodeId) + "." + ext;
    }

    public String playbackUrl(Models.Stream stream) {
        if (stream == null) return "";
        if (!stream.directUrl.trim().isEmpty()) return stream.directUrl;
        return switch (stream.type) {
            case LIVE -> liveUrl(stream.id);
            case VOD -> vodUrl(stream.id, stream.extension);
            case EPISODE -> seriesUrl(stream.id, stream.extension);
            case SERIES -> "";
        };
    }

    public static String normalizeServer(String raw) {
        String value = raw == null ? "" : raw.trim();
        if (value.trim().isEmpty()) value = DEFAULT_SERVER;
        if (!value.startsWith("http://") && !value.startsWith("https://")) {
            value = "http://" + value;
        }
        int getIndex = value.indexOf("/get.php");
        if (getIndex > 0) value = value.substring(0, getIndex);
        int apiIndex = value.indexOf("/player_api.php");
        if (apiIndex > 0) value = value.substring(0, apiIndex);
        while (value.endsWith("/")) value = value.substring(0, value.length() - 1);
        return value;
    }

    private static String sanitizeExtension(String extension, String fallback) {
        String ext = extension == null ? "" : extension.trim().toLowerCase();
        ext = ext.replaceAll("[^a-z0-9]", "");
        return ext.trim().isEmpty() ? fallback : ext;
    }

    private static String enc(String value) {
        try {
            return URLEncoder.encode(value == null ? "" : value, StandardCharsets.UTF_8.name());
        } catch (UnsupportedEncodingException impossible) {
            return value == null ? "" : value;
        }
    }

    private static String encPath(String value) {
        return enc(value).replace("+", "%20");
    }
}
