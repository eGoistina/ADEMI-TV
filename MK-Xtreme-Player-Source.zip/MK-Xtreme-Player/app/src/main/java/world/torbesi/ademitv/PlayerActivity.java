package world.torbesi.ademitv;

import android.os.Bundle;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.OptIn;
import androidx.appcompat.app.AppCompatActivity;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.DefaultLoadControl;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.ui.PlayerView;

import java.util.Locale;

public class PlayerActivity extends AppCompatActivity {
    private ExoPlayer player;
    private PlayerView playerView;
    private LinearLayout errorPanel;
    private TextView errorText;
    private String streamUrl;
    private String fallbackStreamUrl;
    private boolean triedFallback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(R.layout.activity_player);
        hideSystemBars();

        streamUrl = getIntent().getStringExtra("stream_url");
        fallbackStreamUrl = getIntent().getStringExtra("stream_url_fallback");
        String name = getIntent().getStringExtra("stream_name");
        ((TextView) findViewById(R.id.playerTitle)).setText(name == null || name.isEmpty() ? "АДЕМИ ТВ" : name);

        playerView = findViewById(R.id.playerView);
        errorPanel = findViewById(R.id.errorPanel);
        errorText = findViewById(R.id.playerErrorText);
        Button retry = findViewById(R.id.retryButton);
        retry.setOnClickListener(v -> restart());
    }

    private void hideSystemBars() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            if (getWindow().getInsetsController() != null) {
                getWindow().getInsetsController().hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
            }
        } else {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            );
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        startPlayer();
    }

    @OptIn(markerClass = UnstableApi.class)
    private void startPlayer() {
        if (player != null || streamUrl == null || streamUrl.trim().isEmpty()) {
            if (streamUrl == null || streamUrl.trim().isEmpty()) showError("Нема валидна TS адреса за овој канал.");
            return;
        }

        errorPanel.setVisibility(View.GONE);
        DefaultLoadControl loadControl = new DefaultLoadControl.Builder()
                .setBufferDurationsMs(15000, 60000, 2000, 4000)
                .build();

        DefaultHttpDataSource.Factory httpFactory = new DefaultHttpDataSource.Factory()
                .setUserAgent("ADEMI-TV/2.1 Android TS")
                .setAllowCrossProtocolRedirects(true)
                .setConnectTimeoutMs(15000)
                .setReadTimeoutMs(45000);

        player = new ExoPlayer.Builder(this)
                .setLoadControl(loadControl)
                .setMediaSourceFactory(new DefaultMediaSourceFactory(httpFactory))
                .build();
        playerView.setPlayer(player);
        player.addListener(new Player.Listener() {
            @Override
            public void onPlayerError(PlaybackException error) {
                if (!triedFallback && fallbackStreamUrl != null && !fallbackStreamUrl.trim().isEmpty()
                        && !fallbackStreamUrl.equals(streamUrl)) {
                    triedFallback = true;
                    streamUrl = fallbackStreamUrl;
                    releasePlayer();
                    startPlayer();
                    return;
                }
                showError("TS каналот моментално не може да се пушти. Проверете го серверот или обидете се повторно.");
            }
        });

        MediaItem.Builder item = new MediaItem.Builder().setUri(streamUrl);
        if (streamUrl.toLowerCase(Locale.ROOT).contains(".ts")) {
            item.setMimeType(MimeTypes.VIDEO_MP2T);
        }
        player.setMediaItem(item.build());
        player.prepare();
        player.play();
    }

    private void showError(String message) {
        errorText.setText(message);
        errorPanel.setVisibility(View.VISIBLE);
    }

    private void restart() {
        releasePlayer();
        triedFallback = false;
        streamUrl = getIntent().getStringExtra("stream_url");
        startPlayer();
    }

    private void releasePlayer() {
        if (player != null) {
            player.release();
            player = null;
        }
    }

    @Override
    protected void onStop() {
        releasePlayer();
        super.onStop();
    }
}
