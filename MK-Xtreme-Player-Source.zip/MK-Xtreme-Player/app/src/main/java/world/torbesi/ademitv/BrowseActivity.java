package world.torbesi.ademitv;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class BrowseActivity extends AppCompatActivity {
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final List<AppData.StreamItem> allItems = new ArrayList<>();
    private final List<AppData.StreamItem> shownItems = new ArrayList<>();
    private final List<String> shownNames = new ArrayList<>();

    private ArrayAdapter<String> adapter;
    private EditText searchInput;
    private ProgressBar progress;
    private TextView status;
    private boolean favoritesMode;
    private boolean movieMode;
    private String section;
    private String voiceLanguage;
    private ActivityResultLauncher<Intent> speechLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (!AppData.hasLogin(this)) {
            startActivity(new Intent(this, MainActivity.class));
            finish();
            return;
        }
        setContentView(R.layout.activity_browse);

        favoritesMode = getIntent().getBooleanExtra("favorites", false);
        section = getIntent().getStringExtra("section");
        movieMode = AppData.SECTION_GERMAN_MOVIES.equals(section);
        voiceLanguage = getIntent().getStringExtra("voice_language");
        if (voiceLanguage == null || voiceLanguage.trim().isEmpty()) voiceLanguage = "mk-MK";
        String title = getIntent().getStringExtra("title");
        if (title == null || title.trim().isEmpty()) title = movieMode ? "Филмови" : "Канали";

        ((TextView) findViewById(R.id.titleText)).setText(title);
        findViewById(R.id.backButton).setOnClickListener(v -> finish());

        searchInput = findViewById(R.id.searchInput);
        Button voiceButton = findViewById(R.id.voiceButton);
        ListView listView = findViewById(R.id.listView);
        progress = findViewById(R.id.listProgress);
        status = findViewById(R.id.listStatus);

        adapter = new ArrayAdapter<>(this, R.layout.list_item, R.id.itemText, shownNames);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener((parent, view, position, id) -> play(shownItems.get(position)));
        listView.setOnItemLongClickListener((parent, view, position, id) -> {
            AppData.StreamItem item = shownItems.get(position);
            boolean added = AppData.toggleFavorite(this, item);
            Toast.makeText(this, added ? "Додадено во омилени" : "Отстрането од омилени", Toast.LENGTH_SHORT).show();
            if (favoritesMode) loadFavorites(); else applyFilter(searchInput.getText().toString());
            return true;
        });

        searchInput.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { applyFilter(s.toString()); }
            @Override public void afterTextChanged(Editable s) {}
        });

        speechLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() != Activity.RESULT_OK || result.getData() == null) return;
                    ArrayList<String> phrases = result.getData().getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                    applyVoiceResult(phrases);
                }
        );
        voiceButton.setOnClickListener(v -> startVoiceSearch());

        if (favoritesMode) loadFavorites(); else loadSection();
    }

    private void startVoiceSearch() {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, voiceLanguage);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, voiceLanguage);
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 8);
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, movieMode
                ? "Кажете го името на филмот"
                : "Кажете го името на каналот");
        try {
            speechLauncher.launch(intent);
        } catch (ActivityNotFoundException error) {
            Toast.makeText(this, "Гласовното пребарување не е достапно на овој уред.", Toast.LENGTH_LONG).show();
        }
    }

    private void applyVoiceResult(List<String> phrases) {
        if (phrases == null || phrases.isEmpty()) return;
        AppData.SearchResult result = AppData.findBestMatch(allItems, phrases);
        if (result.item != null && result.score >= 58) {
            searchInput.setText(result.item.name);
            searchInput.setSelection(searchInput.length());
            Toast.makeText(this, "Пронајдено: " + result.item.name, Toast.LENGTH_SHORT).show();
        } else {
            searchInput.setText(phrases.get(0));
            searchInput.setSelection(searchInput.length());
            Toast.makeText(this, "Нема точно совпаѓање. Проверете го напишаното име.", Toast.LENGTH_SHORT).show();
        }
    }

    private void loadFavorites() {
        allItems.clear();
        allItems.addAll(AppData.getFavorites(this));
        progress.setVisibility(View.GONE);
        status.setText(allItems.isEmpty()
                ? "Нема омилени. Долго притиснете на канал или филм за да го зачувате."
                : allItems.size() + " омилени");
        applyFilter("");
    }

    private void loadSection() {
        progress.setVisibility(View.VISIBLE);
        status.setText(movieMode ? "Се вчитуваат германските филмови…" : "Се вчитуваат каналите…");
        executor.execute(() -> {
            try {
                List<AppData.StreamItem> loaded = AppData.loadSection(this, section);
                runOnUiThread(() -> {
                    allItems.clear();
                    allItems.addAll(loaded);
                    progress.setVisibility(View.GONE);
                    if (loaded.isEmpty()) {
                        status.setText(movieMode
                                ? "Не е пронајдена категорија со германски филмови."
                                : "Не се пронајдени канали за оваа категорија.");
                    } else {
                        status.setText(loaded.size() + (movieMode ? " германски филмови" : " канали"));
                    }
                    applyFilter("");
                });
            } catch (Exception error) {
                runOnUiThread(() -> {
                    progress.setVisibility(View.GONE);
                    status.setText("Грешка при вчитување: " + safeMessage(error));
                });
            }
        });
    }

    private void applyFilter(String query) {
        shownItems.clear();
        shownNames.clear();
        for (AppData.StreamItem item : allItems) {
            if (AppData.searchMatches(item.name, query)) {
                shownItems.add(item);
                shownNames.add((AppData.isFavorite(this, item) ? "★  " : "") + item.name);
            }
        }
        adapter.notifyDataSetChanged();
        if (!query.trim().isEmpty() && shownItems.isEmpty()) {
            status.setText("Нема резултат за: " + query.trim());
        }
    }

    private void play(AppData.StreamItem item) {
        Intent intent = new Intent(this, PlayerActivity.class);
        intent.putExtra("stream_url", AppData.streamUrl(this, item));
        intent.putExtra("stream_name", item.name);
        startActivity(intent);
    }

    private String safeMessage(Exception error) {
        String message = error.getMessage();
        return message == null || message.trim().isEmpty() ? "непозната грешка" : message;
    }

    @Override
    protected void onDestroy() {
        executor.shutdownNow();
        super.onDestroy();
    }
}
