package world.torbesi.ademitv;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import org.json.JSONObject;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private EditText serverInput;
    private EditText usernameInput;
    private EditText passwordInput;
    private Button loginButton;
    private ProgressBar progress;
    private TextView status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (AppData.hasLogin(this)) {
            openHome();
            return;
        }
        setContentView(R.layout.activity_login);
        applyInsets(findViewById(R.id.loginRoot));

        serverInput = findViewById(R.id.serverInput);
        usernameInput = findViewById(R.id.usernameInput);
        passwordInput = findViewById(R.id.passwordInput);
        loginButton = findViewById(R.id.loginButton);
        progress = findViewById(R.id.loginProgress);
        status = findViewById(R.id.statusText);

        loginButton.setOnClickListener(v -> attemptLogin());
    }

    private void applyInsets(View root) {
        int left = root.getPaddingLeft();
        int top = root.getPaddingTop();
        int right = root.getPaddingRight();
        int bottom = root.getPaddingBottom();
        ViewCompat.setOnApplyWindowInsetsListener(root, (view, insets) -> {
            androidx.core.graphics.Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            view.setPadding(left + bars.left, top + bars.top, right + bars.right, bottom + bars.bottom);
            return insets;
        });
        ViewCompat.requestApplyInsets(root);
    }

    private void attemptLogin() {
        String server = serverInput.getText().toString().trim();
        String username = usernameInput.getText().toString().trim();
        String password = passwordInput.getText().toString();

        if (server.isEmpty() || username.isEmpty() || password.isEmpty()) {
            status.setText("Внесете сервер, корисничко име и лозинка.");
            return;
        }

        AppData.saveLogin(this, server, username, password);
        setLoading(true, "Се проверува директната TS врска…");

        executor.execute(() -> {
            try {
                JSONObject root = new JSONObject(AppData.httpGet(AppData.apiUrl(this, null)));
                JSONObject userInfo = root.optJSONObject("user_info");
                boolean authenticated = userInfo != null && (
                        userInfo.optInt("auth", 0) == 1
                                || "1".equals(userInfo.optString("auth"))
                                || userInfo.optBoolean("auth", false)
                );
                runOnUiThread(() -> {
                    if (authenticated) {
                        openHome();
                    } else {
                        AppData.clearLogin(this);
                        setLoading(false, "Погрешни податоци. Проверете ги серверот, корисничкото име и лозинката.");
                    }
                });
            } catch (Exception error) {
                runOnUiThread(() -> {
                    AppData.clearLogin(this);
                    setLoading(false, "Нема врска со серверот. " + AppData.friendlyError(error));
                });
            }
        });
    }

    private void setLoading(boolean loading, String message) {
        progress.setVisibility(loading ? View.VISIBLE : View.GONE);
        loginButton.setEnabled(!loading);
        serverInput.setEnabled(!loading);
        usernameInput.setEnabled(!loading);
        passwordInput.setEnabled(!loading);
        status.setText(message);
    }

    private void openHome() {
        startActivity(new Intent(this, HomeActivity.class));
        finish();
    }

    @Override
    protected void onDestroy() {
        executor.shutdownNow();
        super.onDestroy();
    }
}
