package world.torbesi.ademitv;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONObject;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private EditText serverInput;
    private EditText usernameInput;
    private EditText passwordInput;
    private Spinner outputSpinner;
    private Button loginButton;
    private ProgressBar progress;
    private TextView status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (AppData.hasLogin(this)) {
            openHome();
            return;
        }
        setContentView(R.layout.activity_login);

        serverInput = findViewById(R.id.serverInput);
        usernameInput = findViewById(R.id.usernameInput);
        passwordInput = findViewById(R.id.passwordInput);
        outputSpinner = findViewById(R.id.outputSpinner);
        loginButton = findViewById(R.id.loginButton);
        progress = findViewById(R.id.loginProgress);
        status = findViewById(R.id.statusText);

        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                new String[]{"m3u8", "ts"}
        );
        outputSpinner.setAdapter(spinnerAdapter);
        loginButton.setOnClickListener(v -> attemptLogin());
    }

    private void attemptLogin() {
        String server = serverInput.getText().toString().trim();
        String username = usernameInput.getText().toString().trim();
        String password = passwordInput.getText().toString();
        String output = String.valueOf(outputSpinner.getSelectedItem());

        if (server.isEmpty() || username.isEmpty() || password.isEmpty()) {
            status.setText("Внесете сервер, корисничко име и лозинка.");
            return;
        }

        AppData.saveLogin(this, server, username, password, output);
        setLoading(true, "Се проверува врската…");

        executor.execute(() -> {
            try {
                JSONObject root = new JSONObject(AppData.httpGet(AppData.apiUrl(this, null)));
                JSONObject userInfo = root.optJSONObject("user_info");
                boolean authenticated = userInfo != null && (
                        userInfo.optInt("auth", 0) == 1
                                || "1".equals(userInfo.optString("auth"))
                                || userInfo.optBoolean("auth", false)
                );
                runOnUiThread(() -> {
                    if (authenticated) {
                        openHome();
                    } else {
                        AppData.clearLogin(this);
                        setLoading(false, "Погрешни податоци. Проверете и обидете се повторно.");
                    }
                });
            } catch (Exception error) {
                runOnUiThread(() -> {
                    AppData.clearLogin(this);
                    setLoading(false, "Нема врска со серверот: " + safeMessage(error));
                });
            }
        });
    }

    private void setLoading(boolean loading, String message) {
        progress.setVisibility(loading ? View.VISIBLE : View.GONE);
        loginButton.setEnabled(!loading);
        serverInput.setEnabled(!loading);
        usernameInput.setEnabled(!loading);
        passwordInput.setEnabled(!loading);
        outputSpinner.setEnabled(!loading);
        status.setText(message);
    }

    private String safeMessage(Exception error) {
        String message = error.getMessage();
        return message == null || message.trim().isEmpty() ? "непозната грешка" : message;
    }

    private void openHome() {
        startActivity(new Intent(this, HomeActivity.class));
        finish();
    }

    @Override
    protected void onDestroy() {
        executor.shutdownNow();
        super.onDestroy();
    }
}
