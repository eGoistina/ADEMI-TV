package world.torbesi.ademitvxtreme;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.URI;
import java.net.URL;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.net.ssl.HttpsURLConnection;

public final class NetworkClient {
    public static final ExecutorService IO = Executors.newFixedThreadPool(4);
    private static final String USER_AGENT = "AdemiTV-Xtreme/3.0 Android";
    private static final int CONNECT_TIMEOUT = 15000;
    private static final int READ_TIMEOUT = 45000;
    private static final int MAX_TEXT_BYTES = 80 * 1024 * 1024;

    private NetworkClient() {}

    public static final class Response {
        public final int code;
        public final String body;
        public final String effectiveUrl;
        public final Map<String, String> requestHeaders;

        Response(int code, String body, String effectiveUrl, Map<String, String> requestHeaders) {
            this.code = code;
            this.body = body == null ? "" : body;
            this.effectiveUrl = effectiveUrl == null ? "" : effectiveUrl;
            this.requestHeaders = requestHeaders == null ? Collections.emptyMap() : requestHeaders;
        }
    }

    public static final class PreparedUrl {
        public final String url;
        public final Map<String, String> headers;

        PreparedUrl(String url, Map<String, String> headers) {
            this.url = url;
            this.headers = headers == null ? Collections.emptyMap() : headers;
        }
    }

    public static Response getText(String rawUrl) throws IOException {
        try {
            return executeText(rawUrl, Collections.emptyMap());
        } catch (UnknownHostException dnsFailure) {
            PreparedUrl prepared = prepareWithDoh(rawUrl);
            return executeText(prepared.url, prepared.headers);
        }
    }

    public static byte[] getBytes(String rawUrl, int maxBytes) throws IOException {
        PreparedUrl prepared;
        try {
            ensureSystemDns(rawUrl);
            prepared = new PreparedUrl(rawUrl, Collections.emptyMap());
        } catch (UnknownHostException failure) {
            prepared = prepareWithDoh(rawUrl);
        }
        HttpURLConnection connection = open(prepared.url, prepared.headers);
        try {
            int code = connection.getResponseCode();
            if (code < 200 || code >= 300) throw new IOException("HTTP " + code);
            try (InputStream input = new BufferedInputStream(connection.getInputStream());
                 ByteArrayOutputStream output = new ByteArrayOutputStream()) {
                byte[] buffer = new byte[8192];
                int total = 0;
                int read;
                while ((read = input.read(buffer)) != -1) {
                    total += read;
                    if (total > maxBytes) throw new IOException("Датотеката е преголема");
                    output.write(buffer, 0, read);
                }
                return output.toByteArray();
            }
        } finally {
            connection.disconnect();
        }
    }

    public static PreparedUrl prepareForPlayback(String rawUrl) throws IOException {
        try {
            ensureSystemDns(rawUrl);
            return new PreparedUrl(rawUrl, Collections.emptyMap());
        } catch (UnknownHostException failure) {
            return prepareWithDoh(rawUrl);
        }
    }

    private static void ensureSystemDns(String rawUrl) throws IOException {
        try {
            URL url = new URL(rawUrl);
            InetAddress.getByName(url.getHost());
        } catch (UnknownHostException e) {
            throw e;
        } catch (Exception e) {
            throw new IOException("Невалидна URL адреса", e);
        }
    }

    private static Response executeText(String rawUrl, Map<String, String> headers) throws IOException {
        HttpURLConnection connection = open(rawUrl, headers);
        try {
            int code = connection.getResponseCode();
            InputStream stream = code >= 200 && code < 400
                    ? connection.getInputStream()
                    : connection.getErrorStream();
            String body = readText(stream, MAX_TEXT_BYTES);
            if (code < 200 || code >= 400) {
                throw new IOException("HTTP " + code + (body.isEmpty() ? "" : ": " + abbreviate(body, 180)));
            }
            return new Response(code, body, connection.getURL().toString(), headers);
        } finally {
            connection.disconnect();
        }
    }

    private static HttpURLConnection open(String rawUrl, Map<String, String> headers) throws IOException {
        URL url = new URL(rawUrl);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setConnectTimeout(CONNECT_TIMEOUT);
        connection.setReadTimeout(READ_TIMEOUT);
        connection.setInstanceFollowRedirects(true);
        connection.setRequestMethod("GET");
        connection.setRequestProperty("User-Agent", USER_AGENT);
        connection.setRequestProperty("Accept", "application/json,text/plain,application/x-mpegURL,*/*");
        connection.setRequestProperty("Connection", "close");
        for (Map.Entry<String, String> entry : headers.entrySet()) {
            connection.setRequestProperty(entry.getKey(), entry.getValue());
        }
        return connection;
    }

    private static PreparedUrl prepareWithDoh(String rawUrl) throws IOException {
        try {
            URL original = new URL(rawUrl);
            String host = original.getHost();
            if (host == null || host.trim().isEmpty()) throw new IOException("URL адресата нема сервер");
            String ip = resolveARecordWithCloudflare(host);
            int port = original.getPort();
            URI uri = new URI(
                    original.getProtocol(),
                    original.getUserInfo(),
                    ip,
                    port,
                    original.getPath(),
                    original.getQuery(),
                    original.getRef());
            Map<String, String> headers = new HashMap<>();
            String hostHeader = port > 0 ? host + ":" + port : host;
            headers.put("Host", hostHeader);
            return new PreparedUrl(uri.toASCIIString(), headers);
        } catch (IOException e) {
            throw e;
        } catch (Exception e) {
            throw new IOException("Не може да се подготви адресата на серверот", e);
        }
    }

    private static String resolveARecordWithCloudflare(String host) throws IOException {
        String dohUrl = "https://1.1.1.1/dns-query?name="
                + java.net.URLEncoder.encode(host, "UTF-8")
                + "&type=A";
        HttpsURLConnection connection = (HttpsURLConnection) new URL(dohUrl).openConnection();
        connection.setConnectTimeout(10000);
        connection.setReadTimeout(10000);
        connection.setRequestMethod("GET");
        connection.setRequestProperty("Accept", "application/dns-json");
        connection.setRequestProperty("User-Agent", USER_AGENT);
        try {
            int code = connection.getResponseCode();
            if (code != 200) throw new UnknownHostException(host + " (DoH HTTP " + code + ")");
            String body = readText(connection.getInputStream(), 1024 * 1024);
            JSONObject json = new JSONObject(body);
            JSONArray answers = json.optJSONArray("Answer");
            if (answers != null) {
                for (int i = 0; i < answers.length(); i++) {
                    JSONObject answer = answers.optJSONObject(i);
                    if (answer == null || answer.optInt("type") != 1) continue;
                    String data = answer.optString("data", "").trim();
                    if (data.matches("\\d{1,3}(\\.\\d{1,3}){3}")) return data;
                }
            }
            throw new UnknownHostException(host + " (нема DNS A запис)");
        } catch (UnknownHostException e) {
            throw e;
        } catch (Exception e) {
            UnknownHostException wrapped = new UnknownHostException(host + " (DNS-over-HTTPS не успеа)");
            wrapped.initCause(e);
            throw wrapped;
        } finally {
            connection.disconnect();
        }
    }

    private static String readText(InputStream input, int maxBytes) throws IOException {
        if (input == null) return "";
        StringBuilder result = new StringBuilder();
        int total = 0;
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(input, StandardCharsets.UTF_8))) {
            char[] buffer = new char[8192];
            int read;
            while ((read = reader.read(buffer)) != -1) {
                total += read * 2;
                if (total > maxBytes) throw new IOException("Одговорот од серверот е преголем");
                result.append(buffer, 0, read);
            }
        }
        return result.toString();
    }

    public static String friendlyMessage(Throwable error) {
        Throwable root = error;
        while (root.getCause() != null && root.getCause() != root) root = root.getCause();
        String message = root.getMessage() == null ? root.getClass().getSimpleName() : root.getMessage();
        if (root instanceof UnknownHostException || message.toLowerCase().contains("resolve host")) {
            return "Серверската адреса не може да се пронајде преку DNS. Проверете ја адресата или контактирајте го ТВ-провајдерот.";
        }
        if (message.toLowerCase().contains("timeout") || message.toLowerCase().contains("timed out")) {
            return "Серверот не одговори навреме. Обидете се повторно.";
        }
        if (message.contains("401") || message.contains("403")) {
            return "Серверот ги одби податоците за пристап.";
        }
        return abbreviate(message, 260);
    }

    private static String abbreviate(String text, int max) {
        if (text == null) return "";
        String clean = text.replaceAll("\\s+", " ").trim();
        return clean.length() <= max ? clean : clean.substring(0, max) + "…";
    }
}
