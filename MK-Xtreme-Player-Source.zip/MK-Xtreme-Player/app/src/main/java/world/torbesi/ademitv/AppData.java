package world.torbesi.ademitv;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

final class AppData {
    static final String SECTION_MACEDONIAN = "macedonian";
    static final String SECTION_SERBIAN = "serbian";
    static final String SECTION_BOSNIAN = "bosnian";
    static final String SECTION_ISLAMIC = "islamic";
    static final String SECTION_SPORTS = "sports";
    static final String SECTION_GERMAN_MOVIES = "german_movies";

    static final String MEDIA_LIVE = "live";
    static final String MEDIA_MOVIE = "movie";

    /*
     * This is the complete M3U-Plus endpoint supplied by the account owner.
     * output=mpegts means the playlist contains direct MPEG-TS live stream addresses.
     */
    private static final String PLAYLIST_URL =
            "http://line.queen-4k.cc/get.php?username=482075061933200&password=403703471074612&type=m3u_plus&output=mpegts";

    private static final String PREFS = "ademi_tv_v22_preferences";
    private static final String KEY_FAVORITES = "favorites";
    private static final long CACHE_MAX_AGE_MS = 15L * 60L * 1000L;

    private static List<StreamItem> playlistCache = Collections.emptyList();
    private static long playlistLoadedAt;

    private AppData() {}

    static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static synchronized void clearPlaylistCache() {
        playlistCache = Collections.emptyList();
        playlistLoadedAt = 0L;
    }

    static synchronized List<StreamItem> loadSection(Context context, String section) throws Exception {
        List<StreamItem> playlist = loadPlaylist(false);
        boolean movieSection = SECTION_GERMAN_MOVIES.equals(section);
        Map<String, StreamItem> unique = new LinkedHashMap<>();

        for (StreamItem item : playlist) {
            if (movieSection && !MEDIA_MOVIE.equals(item.mediaType)) continue;
            if (!movieSection && MEDIA_MOVIE.equals(item.mediaType)) continue;
            if (!categoryMatches(section, item.groupTitle, item.name)) continue;
            unique.put(item.key(), item);
        }

        List<StreamItem> result = new ArrayList<>(unique.values());
        result.sort(Comparator.comparing(item -> normalizeSearch(item.name)));
        return result;
    }

    private static synchronized List<StreamItem> loadPlaylist(boolean force) throws Exception {
        long now = System.currentTimeMillis();
        if (!force && !playlistCache.isEmpty() && now - playlistLoadedAt < CACHE_MAX_AGE_MS) {
            return new ArrayList<>(playlistCache);
        }

        String content = httpGetText(PLAYLIST_URL);
        List<StreamItem> parsed = parseM3u(content);
        if (parsed.isEmpty()) {
            throw new IllegalStateException("Серверот не врати валидна M3U листа со канали.");
        }
        playlistCache = Collections.unmodifiableList(parsed);
        playlistLoadedAt = now;
        return new ArrayList<>(playlistCache);
    }

    private static List<StreamItem> parseM3u(String content) {
        if (content == null) return Collections.emptyList();
        String normalized = content.replace("\r\n", "\n").replace('\r', '\n').trim();
        if (!normalized.startsWith("#EXTM3U")) return Collections.emptyList();

        List<StreamItem> result = new ArrayList<>();
        String pendingName = "";
        String pendingGroup = "";
        String pendingLogo = "";

        for (String rawLine : normalized.split("\n")) {
            String line = rawLine == null ? "" : rawLine.trim();
            if (line.isEmpty()) continue;

            if (line.startsWith("#EXTINF")) {
                pendingGroup = attribute(line, "group-title");
                pendingLogo = attribute(line, "tvg-logo");
                String tvgName = attribute(line, "tvg-name");
                int comma = line.lastIndexOf(',');
                String displayName = comma >= 0 ? line.substring(comma + 1).trim() : "";
                pendingName = !displayName.isEmpty() ? displayName : tvgName;
                continue;
            }

            if (line.startsWith("#")) continue;
            if (!line.startsWith("http://") && !line.startsWith("https://")) continue;

            String name = pendingName.isEmpty() ? "Канал" : pendingName;
            String mediaType = isMovie(line, pendingGroup) ? MEDIA_MOVIE : MEDIA_LIVE;
            String extension = extensionFromUrl(line);
            result.add(new StreamItem(
                    stableId(line),
                    name,
                    pendingGroup,
                    mediaType,
                    extension,
                    line,
                    pendingLogo
            ));
            pendingName = "";
            pendingGroup = "";
            pendingLogo = "";
        }
        return result;
    }

    private static String attribute(String line, String attributeName) {
        Pattern pattern = Pattern.compile("(?:^|\\s)" + Pattern.quote(attributeName) + "=\\\"([^\\\"]*)\\\"", Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(line);
        return matcher.find() ? matcher.group(1).trim() : "";
    }

    private static boolean isMovie(String url, String groupTitle) {
        String lowerUrl = url.toLowerCase(Locale.ROOT);
        String group = normalizeCategory(groupTitle);
        return lowerUrl.contains("/movie/")
                || lowerUrl.matches(".*\\.(mp4|mkv|avi|mov|wmv|m4v)(?:\\?.*)?$")
                || containsAny(group, "movie", "movies", "film", "filme", "filmov", "кино", "филм");
    }

    private static String extensionFromUrl(String url) {
        String withoutQuery = url == null ? "" : url.split("\\?", 2)[0];
        int slash = withoutQuery.lastIndexOf('/');
        int dot = withoutQuery.lastIndexOf('.');
        if (dot > slash && dot < withoutQuery.length() - 1) {
            return withoutQuery.substring(dot + 1).toLowerCase(Locale.ROOT);
        }
        return "";
    }

    private static String stableId(String value) {
        try {
            byte[] hash = MessageDigest.getInstance("SHA-256").digest(value.getBytes(StandardCharsets.UTF_8));
            StringBuilder out = new StringBuilder();
            for (int i = 0; i < 10 && i < hash.length; i++) out.append(String.format(Locale.ROOT, "%02x", hash[i]));
            return out.toString();
        } catch (Exception ignored) {
            return Integer.toHexString(value.hashCode());
        }
    }

    static String streamUrl(Context context, StreamItem item) {
        return item == null ? "" : item.url;
    }

    static String alternateLiveStreamUrl(Context context, StreamItem item) {
        return "";
    }

    static String httpGetText(String urlString) throws Exception {
        HttpURLConnection connection = (HttpURLConnection) new URL(urlString).openConnection();
        connection.setRequestMethod("GET");
        connection.setConnectTimeout(20000);
        connection.setReadTimeout(90000);
        connection.setInstanceFollowRedirects(true);
        connection.setRequestProperty("Accept", "*/*");
        connection.setRequestProperty("Accept-Encoding", "identity");
        connection.setRequestProperty("Connection", "close");
        connection.setRequestProperty("User-Agent", "VLC/3.0.21 LibVLC/3.0.21");

        int status = connection.getResponseCode();
        InputStream input = status >= 200 && status < 300
                ? connection.getInputStream()
                : connection.getErrorStream();
        StringBuilder body = new StringBuilder();
        if (input != null) {
            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(input, StandardCharsets.UTF_8))) {
                String line;
                while ((line = reader.readLine()) != null) body.append(line).append('\n');
            }
        }
        connection.disconnect();
        if (status < 200 || status >= 300) throw new IllegalStateException("HTTP " + status);
        return body.toString();
    }

    static String friendlyError(Throwable error) {
        Throwable current = error;
        while (current != null) {
            if (current instanceof java.net.UnknownHostException) {
                return "Доменот line.queen-4k.cc не може да се пронајде преку DNS. Проверете ја адресата или интернет-мрежата.";
            }
            if (current instanceof java.net.SocketTimeoutException) {
                return "Серверот не одговори навреме. Обидете се повторно.";
            }
            if (current instanceof java.net.ConnectException) {
                return "Серверот одби врска или моментално не работи.";
            }
            if (current instanceof javax.net.ssl.SSLException) {
                return "Серверот има проблем со безбедната HTTPS врска.";
            }
            current = current.getCause();
        }
        String message = error == null ? "" : error.getMessage();
        return message == null || message.trim().isEmpty() ? "Непозната грешка." : message;
    }

    private static boolean categoryMatches(String section, String groupTitle, String itemName) {
        String value = " " + normalizeCategory((groupTitle == null ? "" : groupTitle) + " " + (itemName == null ? "" : itemName)) + " ";
        switch (section == null ? "" : section) {
            case SECTION_MACEDONIAN:
                return containsAny(value, "macedon", "makedon", "макед", "north macedonia", "severna makedonija")
                        || hasToken(value, "mk") || hasToken(value, "mkd") || hasToken(value, "мк");
            case SECTION_SERBIAN:
                return containsAny(value, "serb", "srb", "срб", "srbija", "serbia");
            case SECTION_BOSNIAN:
                return containsAny(value, "bosn", "босн", "bosna", "bosnia")
                        || hasToken(value, "bih") || hasToken(value, "бих");
            case SECTION_ISLAMIC:
                return containsAny(value, "islam", "ислам", "muslim", "муслим", "quran", "kuran", "куран",
                        "diyanet", "dini", "religija", "religious", "ramazan", "ramadan");
            case SECTION_SPORTS:
                return containsAny(value, "sport", "спорт", "fudbal", "football", "arena", "eurosport");
            case SECTION_GERMAN_MOVIES:
                return containsAny(value, "deutsch", "german", "germany", "de filme", "de movies", "немач", "герман")
                        || hasToken(value, "de") || hasToken(value, "deu") || hasToken(value, "ger");
            default:
                return false;
        }
    }

    private static String normalizeCategory(String value) {
        if (value == null) return "";
        return value.toLowerCase(Locale.ROOT)
                .replaceAll("[^\\p{L}\\p{N}]+", " ")
                .replaceAll("\\s+", " ")
                .trim();
    }

    private static boolean containsAny(String text, String... parts) {
        for (String part : parts) if (text.contains(part)) return true;
        return false;
    }

    private static boolean hasToken(String text, String token) {
        return text.contains(" " + token + " ");
    }

    static boolean searchMatches(String candidate, String query) {
        String c = normalizeSearch(candidate);
        String q = normalizeSearch(query);
        if (q.isEmpty()) return true;
        if (c.contains(q)) return true;
        String[] tokens = q.split(" ");
        for (String token : tokens) {
            if (token.length() >= 2 && !c.contains(token)) return false;
        }
        return true;
    }

    static SearchResult findBestMatch(List<StreamItem> items, List<String> spokenPhrases) {
        SearchResult best = new SearchResult(null, "", 0);
        if (spokenPhrases == null) return best;
        for (String phrase : spokenPhrases) {
            String query = normalizeSearch(phrase);
            if (query.isEmpty()) continue;
            for (StreamItem item : items) {
                int score = scoreMatch(normalizeSearch(item.name), query);
                if (score > best.score) best = new SearchResult(item, phrase, score);
            }
        }
        return best;
    }

    private static int scoreMatch(String candidate, String query) {
        if (candidate.isEmpty() || query.isEmpty()) return 0;
        if (candidate.equals(query)) return 100;
        if (candidate.startsWith(query)) return 94;
        if (candidate.contains(query)) return 88;
        if (query.contains(candidate) && candidate.length() >= 4) return 84;
        int tokenScore = 0;
        int tokenCount = 0;
        for (String token : query.split(" ")) {
            if (token.length() < 2) continue;
            tokenCount++;
            if (candidate.contains(token)) tokenScore += 18;
        }
        if (tokenCount > 0 && tokenScore == tokenCount * 18) tokenScore += 25;
        String compactCandidate = candidate.replace(" ", "");
        String compactQuery = query.replace(" ", "");
        int distance = levenshtein(compactCandidate, compactQuery);
        int longest = Math.max(compactCandidate.length(), compactQuery.length());
        int similarity = longest == 0 ? 0 : Math.max(0, 100 - (distance * 100 / longest));
        return Math.max(tokenScore, similarity >= 70 ? similarity : 0);
    }

    private static int levenshtein(String a, String b) {
        int[] previous = new int[b.length() + 1];
        int[] current = new int[b.length() + 1];
        for (int j = 0; j <= b.length(); j++) previous[j] = j;
        for (int i = 1; i <= a.length(); i++) {
            current[0] = i;
            for (int j = 1; j <= b.length(); j++) {
                int cost = a.charAt(i - 1) == b.charAt(j - 1) ? 0 : 1;
                current[j] = Math.min(Math.min(current[j - 1] + 1, previous[j] + 1), previous[j - 1] + cost);
            }
            int[] temp = previous;
            previous = current;
            current = temp;
        }
        return previous[b.length()];
    }

    static String normalizeSearch(String value) {
        if (value == null) return "";
        String lower = value.toLowerCase(Locale.ROOT)
                .replace('č', 'c').replace('ć', 'c').replace('š', 's').replace('ž', 'z').replace('đ', 'd');
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < lower.length(); i++) {
            char ch = lower.charAt(i);
            switch (ch) {
                case 'а': out.append('a'); break;
                case 'б': out.append('b'); break;
                case 'в': out.append('v'); break;
                case 'г': out.append('g'); break;
                case 'д': out.append('d'); break;
                case 'ѓ': out.append("gj"); break;
                case 'е': out.append('e'); break;
                case 'ж': out.append('z'); break;
                case 'з': out.append('z'); break;
                case 'ѕ': out.append("dz"); break;
                case 'и': out.append('i'); break;
                case 'ј': out.append('j'); break;
                case 'к': out.append('k'); break;
                case 'л': out.append('l'); break;
                case 'љ': out.append("lj"); break;
                case 'м': out.append('m'); break;
                case 'н': out.append('n'); break;
                case 'њ': out.append("nj"); break;
                case 'о': out.append('o'); break;
                case 'п': out.append('p'); break;
                case 'р': out.append('r'); break;
                case 'с': out.append('s'); break;
                case 'т': out.append('t'); break;
                case 'ќ': out.append("kj"); break;
                case 'у': out.append('u'); break;
                case 'ф': out.append('f'); break;
                case 'х': out.append('h'); break;
                case 'ц': out.append('c'); break;
                case 'ч': out.append('c'); break;
                case 'џ': out.append("dz"); break;
                case 'ш': out.append('s'); break;
                default:
                    if (Character.isLetterOrDigit(ch)) out.append(ch); else out.append(' ');
            }
        }
        return out.toString()
                .replaceAll("\\b(hd|fhd|uhd|4k|sd|tv|hevc|backup|vip)\\b", " ")
                .replaceAll("[^a-z0-9]+", " ")
                .replaceAll("\\s+", " ")
                .trim();
    }

    static List<StreamItem> getFavorites(Context context) {
        List<StreamItem> result = new ArrayList<>();
        String raw = prefs(context).getString(KEY_FAVORITES, "[]");
        try {
            JSONArray array = new JSONArray(raw);
            for (int i = 0; i < array.length(); i++) {
                JSONObject object = array.optJSONObject(i);
                if (object != null) result.add(StreamItem.fromJson(object));
            }
        } catch (Exception ignored) {}
        result.sort(Comparator.comparing(item -> normalizeSearch(item.name)));
        return result;
    }

    static boolean isFavorite(Context context, StreamItem item) {
        for (StreamItem saved : getFavorites(context)) if (saved.key().equals(item.key())) return true;
        return false;
    }

    static boolean toggleFavorite(Context context, StreamItem item) {
        Map<String, StreamItem> map = new LinkedHashMap<>();
        for (StreamItem saved : getFavorites(context)) map.put(saved.key(), saved);
        boolean added;
        if (map.containsKey(item.key())) {
            map.remove(item.key());
            added = false;
        } else {
            map.put(item.key(), item);
            added = true;
        }
        JSONArray array = new JSONArray();
        for (StreamItem saved : map.values()) array.put(saved.toJson());
        prefs(context).edit().putString(KEY_FAVORITES, array.toString()).apply();
        return added;
    }

    static final class SearchResult {
        final StreamItem item;
        final String phrase;
        final int score;

        SearchResult(StreamItem item, String phrase, int score) {
            this.item = item;
            this.phrase = phrase == null ? "" : phrase;
            this.score = score;
        }
    }

    static final class StreamItem {
        final String streamId;
        final String name;
        final String groupTitle;
        final String mediaType;
        final String extension;
        final String url;
        final String logoUrl;

        StreamItem(String streamId, String name, String groupTitle, String mediaType,
                   String extension, String url, String logoUrl) {
            this.streamId = streamId == null ? "" : streamId;
            this.name = name == null ? "" : name;
            this.groupTitle = groupTitle == null ? "" : groupTitle;
            this.mediaType = mediaType == null ? MEDIA_LIVE : mediaType;
            this.extension = extension == null ? "" : extension;
            this.url = url == null ? "" : url;
            this.logoUrl = logoUrl == null ? "" : logoUrl;
        }

        String key() {
            return mediaType + ":" + streamId;
        }

        JSONObject toJson() {
            JSONObject object = new JSONObject();
            try {
                object.put("stream_id", streamId);
                object.put("name", name);
                object.put("group_title", groupTitle);
                object.put("media_type", mediaType);
                object.put("extension", extension);
                object.put("url", url);
                object.put("logo_url", logoUrl);
            } catch (Exception ignored) {}
            return object;
        }

        static StreamItem fromJson(JSONObject object) {
            return new StreamItem(
                    object.optString("stream_id"),
                    object.optString("name"),
                    object.optString("group_title"),
                    object.optString("media_type", MEDIA_LIVE),
                    object.optString("extension"),
                    object.optString("url"),
                    object.optString("logo_url")
            );
        }
    }
}
