package world.torbesi.ademitv;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

final class AppData {
    static final String SECTION_MACEDONIAN = "macedonian";
    static final String SECTION_SERBIAN = "serbian";
    static final String SECTION_BOSNIAN = "bosnian";
    static final String SECTION_ISLAMIC = "islamic";
    static final String SECTION_SPORTS = "sports";
    static final String SECTION_GERMAN_MOVIES = "german_movies";

    static final String MEDIA_LIVE = "live";
    static final String MEDIA_MOVIE = "movie";

    private static final String PREFS = "ademi_tv_v2_preferences";
    private static final String KEY_SERVER = "server";
    private static final String KEY_USERNAME = "username";
    private static final String KEY_PASSWORD = "password";
    private static final String KEY_FAVORITES = "favorites";

    private AppData() {}

    static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static void saveLogin(Context context, String server, String username, String password) {
        prefs(context).edit()
                .putString(KEY_SERVER, normalizeServer(server))
                .putString(KEY_USERNAME, username == null ? "" : username.trim())
                .putString(KEY_PASSWORD, password == null ? "" : password)
                .remove("output")
                .apply();
    }

    static void clearLogin(Context context) {
        prefs(context).edit()
                .remove(KEY_SERVER)
                .remove(KEY_USERNAME)
                .remove(KEY_PASSWORD)
                .remove("output")
                .apply();
    }

    static boolean hasLogin(Context context) {
        return !server(context).isEmpty() && !username(context).isEmpty() && !password(context).isEmpty();
    }

    static String server(Context context) {
        return prefs(context).getString(KEY_SERVER, "");
    }

    static String username(Context context) {
        return prefs(context).getString(KEY_USERNAME, "");
    }

    static String password(Context context) {
        return prefs(context).getString(KEY_PASSWORD, "");
    }

    static String normalizeServer(String value) {
        String server = value == null ? "" : value.trim();
        if (server.isEmpty()) return "";
        if (!server.startsWith("http://") && !server.startsWith("https://")) {
            server = "http://" + server;
        }
        while (server.endsWith("/")) server = server.substring(0, server.length() - 1);
        return server;
    }

    static String apiUrl(Context context, String action) {
        Uri.Builder builder = Uri.parse(server(context) + "/player_api.php").buildUpon()
                .appendQueryParameter("username", username(context))
                .appendQueryParameter("password", password(context));
        if (action != null && !action.trim().isEmpty()) {
            builder.appendQueryParameter("action", action);
        }
        return builder.build().toString();
    }

    static String streamUrl(Context context, StreamItem item) {
        if (MEDIA_MOVIE.equals(item.mediaType)) {
            return Uri.parse(server(context)).buildUpon()
                    .appendPath("movie")
                    .appendPath(username(context))
                    .appendPath(password(context))
                    .appendPath(item.streamId + "." + cleanExtension(item.extension, "mp4"))
                    .build().toString();
        }
        return Uri.parse(server(context)).buildUpon()
                .appendPath("live")
                .appendPath(username(context))
                .appendPath(password(context))
                .appendPath(item.streamId + ".ts")
                .build().toString();
    }

    static String alternateLiveStreamUrl(Context context, StreamItem item) {
        if (MEDIA_MOVIE.equals(item.mediaType)) return "";
        return Uri.parse(server(context)).buildUpon()
                .appendPath(username(context))
                .appendPath(password(context))
                .appendPath(item.streamId + ".ts")
                .build().toString();
    }

    static String httpGet(String urlString) throws Exception {
        HttpURLConnection connection = (HttpURLConnection) new URL(urlString).openConnection();
        connection.setRequestMethod("GET");
        connection.setConnectTimeout(15000);
        connection.setReadTimeout(40000);
        connection.setInstanceFollowRedirects(true);
        connection.setRequestProperty("Accept", "application/json, text/plain, */*");
        connection.setRequestProperty("User-Agent", "ADEMI-TV/2.1 Android TS");

        int status = connection.getResponseCode();
        InputStream input = status >= 200 && status < 300
                ? connection.getInputStream()
                : connection.getErrorStream();
        StringBuilder body = new StringBuilder();
        if (input != null) {
            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(input, StandardCharsets.UTF_8))) {
                String line;
                while ((line = reader.readLine()) != null) body.append(line);
            }
        }
        connection.disconnect();
        if (status < 200 || status >= 300) {
            throw new IllegalStateException("HTTP " + status);
        }
        return body.toString();
    }

    static String friendlyError(Throwable error) {
        Throwable current = error;
        while (current != null) {
            if (current instanceof java.net.UnknownHostException) {
                return "Адресата на серверот не постои или DNS не може да ја пронајде.";
            }
            if (current instanceof java.net.SocketTimeoutException) {
                return "Серверот не одговори навреме. Обидете се повторно.";
            }
            if (current instanceof java.net.ConnectException) {
                return "Серверот одби врска или портата не е точна.";
            }
            if (current instanceof javax.net.ssl.SSLException) {
                return "Серверот има проблем со безбедната HTTPS врска.";
            }
            current = current.getCause();
        }
        String message = error == null ? "" : error.getMessage();
        return message == null || message.trim().isEmpty() ? "Непозната грешка." : message;
    }

    static List<StreamItem> loadSection(Context context, String section) throws Exception {
        boolean movieMode = SECTION_GERMAN_MOVIES.equals(section);
        String categoryAction = movieMode ? "get_vod_categories" : "get_live_categories";
        String streamAction = movieMode ? "get_vod_streams" : "get_live_streams";

        JSONArray categories = new JSONArray(httpGet(apiUrl(context, categoryAction)));
        Set<String> allowedCategoryIds = new HashSet<>();
        for (int i = 0; i < categories.length(); i++) {
            JSONObject category = categories.optJSONObject(i);
            if (category == null) continue;
            String id = category.optString("category_id", "").trim();
            String name = category.optString("category_name", "");
            if (!id.isEmpty() && categoryMatches(section, name)) allowedCategoryIds.add(id);
        }

        if (allowedCategoryIds.isEmpty()) return Collections.emptyList();

        JSONArray streams = new JSONArray(httpGet(apiUrl(context, streamAction)));
        Map<String, StreamItem> unique = new LinkedHashMap<>();
        for (int i = 0; i < streams.length(); i++) {
            JSONObject object = streams.optJSONObject(i);
            if (object == null) continue;
            String categoryId = object.optString("category_id", "").trim();
            if (!allowedCategoryIds.contains(categoryId)) continue;

            String streamId = object.optString("stream_id", "").trim();
            if (streamId.isEmpty()) continue;
            String name = object.optString("name", movieMode ? "Филм" : "Канал").trim();
            if (name.isEmpty()) name = movieMode ? "Филм" : "Канал";

            StreamItem item = new StreamItem(
                    streamId,
                    name,
                    categoryId,
                    movieMode ? MEDIA_MOVIE : MEDIA_LIVE,
                    movieMode ? object.optString("container_extension", "mp4") : ""
            );
            unique.put(item.key(), item);
        }

        List<StreamItem> result = new ArrayList<>(unique.values());
        result.sort(Comparator.comparing(item -> normalizeSearch(item.name)));
        return result;
    }

    private static boolean categoryMatches(String section, String categoryName) {
        String value = " " + normalizeCategory(categoryName) + " ";
        switch (section == null ? "" : section) {
            case SECTION_MACEDONIAN:
                return containsAny(value, "macedon", "makedon", "макед", "severna makedonija", "north macedonia")
                        || hasToken(value, "mk") || hasToken(value, "mkd") || hasToken(value, "мк");
            case SECTION_SERBIAN:
                return containsAny(value, "serb", "srb", "срб", "srbija", "serbia");
            case SECTION_BOSNIAN:
                return containsAny(value, "bosn", "босн", "bosna", "bosnia")
                        || hasToken(value, "bih") || hasToken(value, "бих");
            case SECTION_ISLAMIC:
                return containsAny(value, "islam", "ислам", "muslim", "муслим", "quran", "kuran", "куран",
                        "diyanet", "dini", "religija", "religious", "ramazan", "ramadan");
            case SECTION_SPORTS:
                return containsAny(value, "sport", "спорт", "fudbal", "football", "arena", "eurosport");
            case SECTION_GERMAN_MOVIES:
                return containsAny(value, "deutsch", "german", "germany", "de filme", "de movies", "немач", "герман")
                        || hasToken(value, "de") || hasToken(value, "deu") || hasToken(value, "ger");
            default:
                return false;
        }
    }

    private static String normalizeCategory(String value) {
        if (value == null) return "";
        return value.toLowerCase(Locale.ROOT)
                .replaceAll("[^\\p{L}\\p{N}]+", " ")
                .replaceAll("\\s+", " ")
                .trim();
    }

    private static boolean containsAny(String text, String... parts) {
        for (String part : parts) if (text.contains(part)) return true;
        return false;
    }

    private static boolean hasToken(String text, String token) {
        return text.contains(" " + token + " ");
    }

    static boolean searchMatches(String candidate, String query) {
        String c = normalizeSearch(candidate);
        String q = normalizeSearch(query);
        if (q.isEmpty()) return true;
        if (c.contains(q)) return true;
        String[] tokens = q.split(" ");
        for (String token : tokens) {
            if (token.length() >= 2 && !c.contains(token)) return false;
        }
        return true;
    }

    static SearchResult findBestMatch(List<StreamItem> items, List<String> spokenPhrases) {
        SearchResult best = new SearchResult(null, "", 0);
        if (spokenPhrases == null) return best;
        for (String phrase : spokenPhrases) {
            String query = normalizeSearch(phrase);
            if (query.isEmpty()) continue;
            for (StreamItem item : items) {
                int score = scoreMatch(normalizeSearch(item.name), query);
                if (score > best.score) best = new SearchResult(item, phrase, score);
            }
        }
        return best;
    }

    private static int scoreMatch(String candidate, String query) {
        if (candidate.isEmpty() || query.isEmpty()) return 0;
        if (candidate.equals(query)) return 100;
        if (candidate.startsWith(query)) return 94;
        if (candidate.contains(query)) return 88;
        if (query.contains(candidate) && candidate.length() >= 4) return 84;

        int tokenScore = 0;
        int tokenCount = 0;
        for (String token : query.split(" ")) {
            if (token.length() < 2) continue;
            tokenCount++;
            if (candidate.contains(token)) tokenScore += 18;
        }
        if (tokenCount > 0 && tokenScore == tokenCount * 18) tokenScore += 25;

        String compactCandidate = candidate.replace(" ", "");
        String compactQuery = query.replace(" ", "");
        int distance = levenshtein(compactCandidate, compactQuery);
        int longest = Math.max(compactCandidate.length(), compactQuery.length());
        int similarity = longest == 0 ? 0 : Math.max(0, 100 - (distance * 100 / longest));
        return Math.max(tokenScore, similarity >= 70 ? similarity : 0);
    }

    private static int levenshtein(String a, String b) {
        int[] previous = new int[b.length() + 1];
        int[] current = new int[b.length() + 1];
        for (int j = 0; j <= b.length(); j++) previous[j] = j;
        for (int i = 1; i <= a.length(); i++) {
            current[0] = i;
            for (int j = 1; j <= b.length(); j++) {
                int cost = a.charAt(i - 1) == b.charAt(j - 1) ? 0 : 1;
                current[j] = Math.min(Math.min(current[j - 1] + 1, previous[j] + 1), previous[j - 1] + cost);
            }
            int[] temp = previous;
            previous = current;
            current = temp;
        }
        return previous[b.length()];
    }

    static String normalizeSearch(String value) {
        if (value == null) return "";
        String lower = value.toLowerCase(Locale.ROOT)
                .replace('č', 'c').replace('ć', 'c').replace('š', 's').replace('ž', 'z').replace('đ', 'd');
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < lower.length(); i++) {
            char ch = lower.charAt(i);
            switch (ch) {
                case 'а': out.append('a'); break;
                case 'б': out.append('b'); break;
                case 'в': out.append('v'); break;
                case 'г': out.append('g'); break;
                case 'д': out.append('d'); break;
                case 'ѓ': out.append("gj"); break;
                case 'е': out.append('e'); break;
                case 'ж': out.append('z'); break;
                case 'з': out.append('z'); break;
                case 'ѕ': out.append("dz"); break;
                case 'и': out.append('i'); break;
                case 'ј': out.append('j'); break;
                case 'к': out.append('k'); break;
                case 'л': out.append('l'); break;
                case 'љ': out.append("lj"); break;
                case 'м': out.append('m'); break;
                case 'н': out.append('n'); break;
                case 'њ': out.append("nj"); break;
                case 'о': out.append('o'); break;
                case 'п': out.append('p'); break;
                case 'р': out.append('r'); break;
                case 'с': out.append('s'); break;
                case 'т': out.append('t'); break;
                case 'ќ': out.append("kj"); break;
                case 'у': out.append('u'); break;
                case 'ф': out.append('f'); break;
                case 'х': out.append('h'); break;
                case 'ц': out.append('c'); break;
                case 'ч': out.append('c'); break;
                case 'џ': out.append("dz"); break;
                case 'ш': out.append('s'); break;
                default:
                    if (Character.isLetterOrDigit(ch)) out.append(ch); else out.append(' ');
            }
        }
        return out.toString()
                .replaceAll("\\b(hd|fhd|uhd|4k|sd|tv|hevc|backup|vip)\\b", " ")
                .replaceAll("[^a-z0-9]+", " ")
                .replaceAll("\\s+", " ")
                .trim();
    }

    static List<StreamItem> getFavorites(Context context) {
        List<StreamItem> result = new ArrayList<>();
        String raw = prefs(context).getString(KEY_FAVORITES, "[]");
        try {
            JSONArray array = new JSONArray(raw);
            for (int i = 0; i < array.length(); i++) {
                JSONObject object = array.optJSONObject(i);
                if (object != null) result.add(StreamItem.fromJson(object));
            }
        } catch (Exception ignored) {
        }
        result.sort(Comparator.comparing(item -> normalizeSearch(item.name)));
        return result;
    }

    static boolean isFavorite(Context context, StreamItem item) {
        for (StreamItem saved : getFavorites(context)) if (saved.key().equals(item.key())) return true;
        return false;
    }

    static boolean toggleFavorite(Context context, StreamItem item) {
        Map<String, StreamItem> map = new LinkedHashMap<>();
        for (StreamItem saved : getFavorites(context)) map.put(saved.key(), saved);
        boolean added;
        if (map.containsKey(item.key())) {
            map.remove(item.key());
            added = false;
        } else {
            map.put(item.key(), item);
            added = true;
        }
        JSONArray array = new JSONArray();
        for (StreamItem saved : map.values()) array.put(saved.toJson());
        prefs(context).edit().putString(KEY_FAVORITES, array.toString()).apply();
        return added;
    }

    private static String cleanExtension(String value, String fallback) {
        String result = value == null ? "" : value.trim().toLowerCase(Locale.ROOT);
        while (result.startsWith(".")) result = result.substring(1);
        return result.isEmpty() ? fallback : result;
    }

    static final class SearchResult {
        final StreamItem item;
        final String phrase;
        final int score;

        SearchResult(StreamItem item, String phrase, int score) {
            this.item = item;
            this.phrase = phrase == null ? "" : phrase;
            this.score = score;
        }
    }

    static final class StreamItem {
        final String streamId;
        final String name;
        final String categoryId;
        final String mediaType;
        final String extension;

        StreamItem(String streamId, String name, String categoryId, String mediaType, String extension) {
            this.streamId = streamId == null ? "" : streamId;
            this.name = name == null ? "" : name;
            this.categoryId = categoryId == null ? "" : categoryId;
            this.mediaType = mediaType == null ? MEDIA_LIVE : mediaType;
            this.extension = extension == null ? "" : extension;
        }

        String key() {
            return mediaType + ":" + streamId;
        }

        JSONObject toJson() {
            JSONObject object = new JSONObject();
            try {
                object.put("stream_id", streamId);
                object.put("name", name);
                object.put("category_id", categoryId);
                object.put("media_type", mediaType);
                object.put("extension", extension);
            } catch (Exception ignored) {}
            return object;
        }

        static StreamItem fromJson(JSONObject object) {
            return new StreamItem(
                    object.optString("stream_id"),
                    object.optString("name"),
                    object.optString("category_id"),
                    object.optString("media_type", MEDIA_LIVE),
                    object.optString("extension")
            );
        }
    }
}
